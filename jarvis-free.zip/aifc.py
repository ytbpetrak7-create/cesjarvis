"""Dummy aifc module for Python 3.14 compatibility"""
class Error(Exception):
    pass
def open(*args, **kwargs):
    raise NotImplementedError("aifc not supported")
