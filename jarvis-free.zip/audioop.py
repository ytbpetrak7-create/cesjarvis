"""Dummy audioop module for Python 3.14 compatibility"""
minval = 2
maxval = 32767
def avg(*a, **k): return 0
def rms(*a, **k): return 0
def findfactor(*a, **k): return 1
def findmax(*a, **k): return 1
def max(*a, **k): return 1
def min(*a, **k): return -1
def bias(*a, **k): return b''
def add(*a, **k): return b''
def mul(*a, **k): return b''
def tomono(*a, **k): return b''
def tostereo(*a, **k): return b''
def lin2lin(*a, **k): return b''
def lin2ulaw(*a, **k): return b''
def ulaw2lin(*a, **k): return b''
def lin2alaw(*a, **k): return b''
def alaw2lin(*a, **k): return b''
def ratecv(*a, **k): return (b'', None)
def getsample(*a, **k): return 0
def getwidth(*a, **k): return 2
def getnchannels(*a, **k): return 1
def getframerate(*a, **k): return 16000
def getnframes(*a, **k): return 0
def getsampwidth(*a, **k): return 2
