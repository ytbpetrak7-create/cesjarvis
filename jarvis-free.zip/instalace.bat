@echo off
title J.A.R.V.I.S. - Instalace
color 0A
echo.
echo  ================================
echo   J.A.R.V.I.S. - Instalace
echo  ================================
echo.

echo [1/5] Kontroluji Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo Python nenalezen. Stahuji...
    curl -L -o python-installer.exe "https://www.python.org/ftp/python/3.14.6/python-3.14.6-amd64.exe"
    if errorlevel 1 (
        echo Chyba pri stahovani. Stahuj rucne: https://www.python.org/downloads/
        pause
        exit /b 1
    )
    echo Instaluj Python (potvrď ANO)...
    python-installer.exe /passive InstallAllUsers=1 PrependPath=1
    del python-installer.exe
    echo Python nainstalovan.
    echo Restartuj...
    pause
    exit /b 0
)
python --version
echo Python OK.

echo.
echo [2/5] Instaluji balicky...
pip install SpeechRecognition sounddevice numpy vosk edge-tts pyautogui pygetwindow pywin32 pyperclip --quiet --disable-pip-version-check

echo.
echo [3/5] Vytvarim dummy moduly...
python -c "open('aifc.py','w').write('class Error(Exception): pass')"
python -c "open('audioop.py','w').write('minval=2\nmaxval=32767')"

echo.
echo [4/5] Stahuji cesky model (~50MB)...
if exist "vosk-model-small-cs-0.4-rhasspy" (
    echo Model uz existuje.
) else (
    python -c "import urllib.request; urllib.request.urlretrieve('https://alphacephei.com/vosk/models/vosk-model-small-cs-0.4-rhasspy.zip', 'model.zip')"
    python -c "import zipfile; zipfile.ZipFile('model.zip').extractall('.'); import os; os.remove('model.zip')"
    echo Model stazeny.
)

echo.
echo [5/5] Hotovo!
echo.
echo ================================
echo  Klikni na: spust.bat
echo ================================
echo.
pause
