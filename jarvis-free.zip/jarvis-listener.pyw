"""
J.A.R.V.I.S. - Automaticke spusteni
Bezi na pozadi a ceka na "Jarvis"
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import subprocess
import sounddevice as sd
import numpy as np
import speech_recognition as sr
import threading
import time

SAMPLE_RATE = 16000
ENERGY_THRESHOLD = 100

def find_mic():
    devices = sd.query_devices()
    for i, d in enumerate(devices):
        if d['max_input_channels'] > 0 and 'oryx' in d['name'].lower():
            return i
    for i, d in enumerate(devices):
        if d['max_input_channels'] > 0 and 'niceboy' in d['name'].lower() and 'bthhfenum' not in d['name'].lower():
            return i
    for i, d in enumerate(devices):
        if d['max_input_channels'] > 0 and 'realtek' in d['name'].lower():
            return i
    for i, d in enumerate(devices):
        name = d['name'].lower()
        if d['max_input_channels'] > 0 and 'microphone' in name and 'steam' not in name:
            return i
    for i, d in enumerate(devices):
        if d['max_input_channels'] > 0:
            return i
    return None

class JarvisListener:
    def __init__(self):
        self.mic_device = find_mic()
        self.recognizer = sr.Recognizer()
        self.running = True
        self.jarvis_running = False
        
    def listen_for_wake(self):
        print("Cekam na 'Jarvis'...", flush=True)
        
        while self.running:
            try:
                audio = sd.rec(int(3 * SAMPLE_RATE), samplerate=SAMPLE_RATE,
                               channels=1, dtype='int16', device=self.mic_device)
                sd.wait()
                
                rms = np.sqrt(np.mean(audio.astype(float) ** 2))
                
                if rms < ENERGY_THRESHOLD:
                    continue
                
                audio_data = sr.AudioData(audio.tobytes(), SAMPLE_RATE, 2)
                
                try:
                    text = self.recognizer.recognize_google(audio_data, language='cs-CZ')
                    print(f"Slysim: {text}", flush=True)
                    
                    if "jarvis" in text.lower():
                        print("Jarvis nalezen! Spoustim...", flush=True)
                        self.start_jarvis()
                except:
                    pass
                    
            except Exception as e:
                print(f"Chyba: {e}", flush=True)
                time.sleep(1)
    
    def start_jarvis(self):
        if self.jarvis_running:
            print("Jiz bezi.", flush=True)
            return
        
        self.jarvis_running = True
        jarvis_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "jarvis.py")
        
        # Spusti jarvis.py v novem procesu
        subprocess.Popen([sys.executable, jarvis_path])
        
        # Pockej kym skonci
        time.sleep(5)
        self.jarvis_running = False
        print("Jarvis skoncil. Cekam na dalsi 'Jarvis'...", flush=True)
    
    def run(self):
        print("=" * 40, flush=True)
        print("J.A.R.V.I.S. - Automaticky poslech", flush=True)
        print("Rekni 'Jarvis' pro spusteni", flush=True)
        print("Stiskni Ctrl+C pro ukonceni", flush=True)
        print("=" * 40, flush=True)
        
        try:
            self.listen_for_wake()
        except KeyboardInterrupt:
            print("Ukonceno.", flush=True)
            self.running = False

if __name__ == "__main__":
    listener = JarvisListener()
    listener.run()
