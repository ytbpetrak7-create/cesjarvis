"""
J.A.R.V.I.S. - Cesky hlasovy asistent
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import datetime
import webbrowser
import random
import numpy as np
import sounddevice as sd
import subprocess
import speech_recognition as sr
import difflib
import uuid
import urllib.parse
import json
import time

SAMPLE_RATE = 16000
ENERGY_THRESHOLD = 100
VOICE = "cs-CZ-AntoninNeural"
VOICE_RATE = "+0%"
VOICE_PITCH = "+0Hz"

def find_mic():
    devices = sd.query_devices()
    for i, d in enumerate(devices):
        if d['max_input_channels'] > 0 and 'oryx' in d['name'].lower():
            return i
    for i, d in enumerate(devices):
        if d['max_input_channels'] > 0 and 'niceboy' in d['name'].lower() and 'bthhfenum' not in d['name'].lower():
            return i
    for i, d in enumerate(devices):
        if d['max_input_channels'] > 0 and 'realtek' in d['name'].lower():
            return i
    for i, d in enumerate(devices):
        name = d['name'].lower()
        if d['max_input_channels'] > 0 and 'microphone' in name and 'steam' not in name:
            return i
    for i, d in enumerate(devices):
        if d['max_input_channels'] > 0:
            return i
    return None

COMMANDS = {
    "pozdrav": ["ahoj", "dobry den", "nazdar", "cau"],
    "cas": ["cas", "hodiny", "kolik je hodin", "kolikata"],
    "datum": ["datum", "kolikateho", "jaký je den"],
    "vtip": ["vtip", "vtipy", "zasmej", "vtipek"],
    "konec": ["konec", "ukonci", "vypni", "nashledanou"],
    "pomoc": ["napoveda", "pomoc", "co umis"],
    "kdo": ["kdo jsi", "jak se jmenujes", "co jsi", "kdo te vytvoril", "kdo te udelal"],
    "diky": ["dekuji", "diky", "dekuju"],
    "google": ["google"],
    "youtube": ["youtube"],
    "seznam": ["seznam"],
    "github": ["github"],
    "brave": ["brave"],
    "zavri": ["zavri", "zavrit"],
    "prohlizec": ["prohlizec", "browser"],
    "tlumik": ["ztlum", "odtlum", "ztis", "utichni", "mlc", "ztlumit", "odtlumit", "mikrofon", "mute"],
    "pripoj": ["pripoj", "zvedni", "prijmi", "hovor"],
    "zaves": ["zaves", "ukonci hovor"],
    "zavolej": ["zavolej", "zavolat", "zavolani"],
    "vyhledej": ["vyhledej", "vyhledat", "najdi", "najit"],
    "stop": ["zastav", "stop", "pauza", "pause", "zastavit", "prestan"],
    "play": ["pust", "prehraj", "hraj", "play"],
    "stazene": ["stazene", "download", "downloads"],
    "hledej": ["hledej", "hledat", "vyhledej na", "vyhledat na"],
    "spust": ["spust", "zapni", "spustit", "zapnout"],
    "nauc_se": ["nauc se", "nauc", "zapamatuj si", "zapamatuj"],
    "zapomenout": ["zapomenout", "zapomen", "vymazat", "odstranit"],
    "co_umis": ["co umis", "co umis delat", "tvoje prikazy"],
    "povidat": ["povidat si", "povidame si", "povidej si", "konverzace", "pokec", "kecat"],
    "kamera": ["co vidis", "co vidiš", "popis", "kamera", "fotka", "vidis", "vidis"],
    "obrazovka": ["co delam", "co delas", "co je na obrazovce", "obrazovka", "screen"],
    "sleduj": ["sleduj", "sleduj me", "zacni sledovat", "start monitoring"],
    "nesleduj": ["nesleduj", "prestat sledovat", "stop monitoring"],
    "zvyky": ["moje zvyky", "co delam", "jak casto", "moje pouziti"],
    "programovani": ["programovani", "programovat", "kod", "kodit", "programovaci jazyk", "jazyk"],
    "napsat": ["napis", "napiš", "vytvor", "vytvorit", "kod", "koduj"],
    "upravit": ["uprav", "upravit", "zmen", "zmenit", "nahrad", "oprav"],
    "najit_kod": ["najdi v kodu", "najdi v souboru", "hledej v kodu"],
    "analyzovat": ["analyzuj", "analyzovat", "co dela tenhle kod", "vysvetli kod"],
    "zapis_soubor": ["zapis do souboru", "pridej do souboru", "nahrad v souboru", "oprav soubor"],
    "uprav_soubor": ["uprav soubor", "zmen soubor", "edituj soubor"],
    "vscode": ["vs code", "visual studio code", "analyzuj vs code", "tipy vs code"],
    "tipy": ["tipy", "co pridat", "co vylepsit", "navrhni vylepseni"],
    "vypni_pc": ["vypni pocitac", "vypni pc", "shutdown", "vypnout"],
    "restartuj": ["restartuj", "restart", "restartuj pc"],
    "uspi": ["uspi pc", "uspi", "sleep", "spci"],
    "uzamkni": ["uzamkni", "zamkni", "lock", "uzamknout"],
    "hlasitost": ["hlasitost", "utichni", "ztiš", "hlasiteji"],
    "jas": ["jas", "svetlejsi", "tmejsi", "jas obrazovky"],
    "wifi": ["wifi", "internet", "pripojeni"],
    "bluetooth": ["bluetooth", "bt"],
    "soubory": ["soubory", "pruzkumnik", "file explorer"],
    "spravce": ["spravce uloh", "task manager", "procesy"],
    "terminal": ["terminal", "cmd", "powershell", "konzole"],
    "nastaveni": ["nastaveni", "settings", "windows settings"],
    "oznameni": ["oznameni", "notifikace", "center"],
    "kalkulacka": ["kalkulacka", "calculator"],
    "poznamky": ["poznamky", "notepad", "poznamkovy blok"],
    "snimek": ["snimek", "screenshot", "capture"],
    "nahravej": ["nahravej", "nahravka", "record"],
    "webtest": ["klikni na text", "klikni", "web test", "test webu"],
    "prezentace": ["prezentace", "prezentaci", "prezentku", "powerpoint", "pptx", "slidy", "snimky"],
    "godot": ["godot", "gdscript"],
    "klic": ["zadej klic", "aktivovat", "aktivace", "licence", "licencni klic"],
}

# Ktere prikazy vyzaduji placenou edici (poradi dulezite: prezentace/godot prvni)
EDICE_PRIKAZU = {
    "prezentace": "MAX",
    "godot": "MAX",
    "vscode": "MAX",
    "tipy": "MAX",
    "webtest": "MAX",
    "kamera": "MAX",
    "obrazovka": "MAX",
    "vypni_pc": "PRO",
    "restartuj": "PRO",
    "uspi": "PRO",
    "uzamkni": "PRO",
    "hlasitost": "PRO",
    "jas": "PRO",
    "wifi": "PRO",
    "bluetooth": "PRO",
    "snimek": "PRO",
    "tlumik": "PRO",
    "pripoj": "PRO",
    "zaves": "PRO",
    "zavolej": "PRO",
    "vyhledej": "PRO",
    "nauc_se": "PRO",
    "programovani": "PRO",
    "napsat": "PRO",
    "upravit": "PRO",
    "najit_kod": "PRO",
    "analyzovat": "PRO",
    "zapis_soubor": "PRO",
    "uprav_soubor": "PRO",
}

# Brany pro chat rezim (MAX skupiny prvni)
BRANY_CHAT = [
    (["prezentace", "prezentaci", "powerpoint", "pptx", "godot", "gdscript"], "MAX"),
    (["vs code", "visual studio"], "MAX"),
    (["klikni na text", "web test"], "MAX"),
    (["kamera", "co vidis", "obrazovka", "screen"], "MAX"),
    (["tipy", "tip na", "porad s kodem", "doporuc"], "MAX"),
    (["vypni pocitac", "vypni pc", "restartuj", "uspi", "uzamkni", "zamkni",
      "hlasitost", "ztis", "utichni", "wifi", "bluetooth", "snimek", "screenshot",
      "ztlum", "odtlum", "pripoj", "zaves", "zavolej",
      "nauc se", "zapamatuj", "programovani", "napis kod", "napis funkci",
      "vytvor funkci", "uprav kod", "oprav kod", "analyzuj", "zkontroluj",
      "zapis do souboru", "uprav soubor", "sleduj"], "PRO"),
]


def fuzzy_match(text, keywords):
    text_lower = text.lower().strip()
    for kw in keywords:
        if kw == text_lower or kw in text_lower:
            return True
    words = text_lower.split()
    for word in words:
        if len(word) > 3:
            for kw in keywords:
                matches = difflib.get_close_matches(word, [kw], n=1, cutoff=0.8)
                if matches:
                    return True
    return False


class JarvisCZ:
    def __init__(self):
        self.running = True
        self.name = "Jarvis"
        self.recognizer = sr.Recognizer()
        self.mic_device = find_mic()
        self.learned_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "learned.json")
        self.learned_commands = self.load_learned()
        try:
            from licence import nacti_edici
            self.edice = nacti_edici()
        except Exception:
            self.edice = "FREE"
        self.screen_log_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "screen_log.json")
        self.screen_log = self.load_screen_log()
        self.monitoring = False
        self.chatting = False
        self.chat_history = []
        self.chat_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chat_history.json")
        self.chat_history = self.load_chat_history()
        self.chat_context = {
            "topic": None,
            "last_question": None,
            "asked_about": [],
            "mood": "neutralni",
            "last_action": None,
            "conversation_count": 0,
            "user_name": None,
            "remembered_facts": []
        }
        if self.mic_device is not None:
            print(f"Mikrofon: {sd.query_devices(self.mic_device)['name']}", flush=True)
        else:
            print("Mikrofon nenalezen!", flush=True)
        print("Google rozpoznavani pripraveno.", flush=True)

    def load_chat_history(self):
        try:
            if os.path.exists(self.chat_file):
                with open(self.chat_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except:
            pass
        return []

    def save_chat_history(self):
        try:
            with open(self.chat_file, 'w', encoding='utf-8') as f:
                json.dump(self.chat_history[-100:], f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Chyba ukladani chatu: {e}", flush=True)

    def chat(self, user_input):
        user_lower = user_input.lower()
        self.chat_history.append({"role": "user", "text": user_input})
        self.chat_context["conversation_count"] += 1

        # Aktivace ma vzdy prednost pred branami
        if any(w in user_lower for w in ["aktivovat", "aktivace", "zadej klic", "licencni klic"]):
            return self.aktivovat_licenci(user_lower)

        # Brana placenych edici pro chat
        for _slova, _need in BRANY_CHAT:
            if any(w in user_lower for w in _slova) and not self.smim(_need):
                return f"Tato funkce je v edici {_need} a vyšší. Najdeš ji na našem webu."

        # Sluchova analyza - obcas neslysi
        if random.random() < 0.03:
            return random.choice([
                "Promiň, co?",
                "Můžeš to zopakovat?",
                "Počkej, neslyšel jsem.",
                "Ehm, co?",
                "Hmm? Promiň."
            ])

        # Obcas premysli
        if random.random() < 0.05:
            print(random.choice(["Hmm...", "Počkej...", "No...", "Ehm...", "Teda..."]), flush=True)

        # Prirozeny jazyk - automaticka detekce
        if any(w in user_lower for w in ["hledej", "vyhledej", "googli"]) or ("co je" in user_lower and len(user_lower.split()) > 2):
            query = user_lower
            for w in ["hledej", "vyhledej", "googli", "co je", "co to je", "jak se dela", "jak funguje"]:
                query = query.replace(w, "").strip()
            if query:
                self.search_web(query)
                return random.choice(["Vyhledávám.", "Hotovo.", "Mám to.", "Hledám."])

        if any(w in user_lower for w in ["otevri", "otevrit", "pust"]):
            for site in ["google", "youtube", "seznam", "wikipedia", "github", "discord", "spotify", "netflix"]:
                if site in user_lower:
                    self.open_website(site)
                    return random.choice(["Otevírám.", "Hotovo.", "Mám to.", "Jede."])
            if "www" in user_lower or ".cz" in user_lower or ".com" in user_lower:
                url = "https://" + user_lower.replace("otevri", "").replace("otevrit", "").replace("pust", "").strip()
                webbrowser.open(url)
                return random.choice(["Otevírám.", "Hotovo.", "Mám to."])

        if any(w in user_lower for w in ["zavri", "zavrit", "ukonci"]):
            self.close_app(user_lower)
            return random.choice(["Zavírám.", "Hotovo.", "Ukončeno."])

        if any(w in user_lower for w in ["kolik je", "kolik hodin", "cas", "jakej cas", "kolik"]):
            return random.choice([f"Je {self.get_time()}.", f"Čas: {self.get_time()}.", f"Teď je {self.get_time()}."])
        if any(w in user_lower for w in ["jakej den", "jaky den", "kolikaty", "datum", "jakej je dnes"]):
            return random.choice([self.get_date(), f"Dnes je {self.get_date()}."])

        if any(w in user_lower for w in ["vtip", "vtipko", "zabav me", "nudim se"]):
            return self.tell_joke()

        if any(w in user_lower for w in ["konec", "odejdi", "nashledanou", "cau pa"]):
            self.chatting = False
            return random.choice(["Nashledanou.", "Pa.", "Čau.", "Kdykoliv se ozvi."])

        if any(w in user_lower for w in ["ukonci", "vypni se", "vypni"]):
            self.chatting = False
            self.running = False
            return random.choice(["Systémy se vypínají.", "Vypínám se."])

        if any(w in user_lower for w in ["nauc se", "zapamatuj si", "zapamatuj"]):
            self.learn_command(user_lower)
            return random.choice(["Naučeno.", "Hotovo.", "Zapamatoval jsem si to."])

        if any(w in user_lower for w in ["napis kod", "vytvor funkci", "napis funkci"]):
            self.write_code(user_lower)
            return random.choice(["Kód je připravený.", "Hotovo.", "Připraveno."])

        if any(w in user_lower for w in ["programovani", "programovat", "kodit", "debug", "bug"]):
            self.programming_help(user_lower)
            return random.choice(["Pomohl jsem ti.", "Hotovo.", "Tu máš."])

        if any(w in user_lower for w in ["uprav kod", "oprav kod", "zmen kod"]):
            self.edit_code(user_lower)
            return random.choice(["Šablona připravená.", "Hotovo.", "Připraveno."])

        if any(w in user_lower for w in ["analyzuj", "analyza", "zkontroluj"]):
            self.analyze_code(user_lower)
            return random.choice(["Analyzuju.", "Hotovo.", "Tu máš."])

        if any(w in user_lower for w in ["zapis do souboru", "uloz do souboru"]):
            self.write_to_file(user_lower)
            return random.choice(["Načítám soubor.", "Hotovo.", "Co chceš změnit?"])

        if any(w in user_lower for w in ["uprav soubor", "oprav soubor"]):
            self.edit_file(user_lower)
            return random.choice(["Upravuji.", "Hotovo.", "Co chceš změnit?"])

        if any(w in user_lower for w in ["vs code", "visual studio"]):
            self.analyze_vscode()
            return random.choice(["Analyzuju VS Code.", "Hotovo."])

        if any(w in user_lower for w in ["tipy", "tip", "porad", "doporuc"]):
            self.suggest_code()
            return random.choice(["Tipy připravené.", "Hotovo."])

        if any(w in user_lower for w in ["klikni na text", "klikni"]):
            self.create_web_test(user_lower)
            return random.choice([
                "Funkce je ve schrance. Pouzij jen na vlastni strance.",
                "Hotovo. Zkontroluj schranku.",
                "Pripraveno. Vloz do konzole prohlizece.",
            ])

        if any(w in user_lower for w in ["godot", "godota", "gdscript"]):
            if any(w in user_lower for w in ["auto", "jezd", "car", "vehicle", "pohyb", "ridi", "řidi"]):
                self.create_godot_car(user_lower)
                return random.choice([
                    "Hotovo. Kod pro auto je ve schrance.",
                    "Mam to. Vloz kod Ctrl+V do Godotu.",
                    "Pripraveno. Zkontroluj schranku.",
                ])
            return random.choice([
                "Godot! Chceš jezdící auto? Rekni: vytvor auto v godotu.",
                "Godot! Co potřebuješ? Auto?",
                "Godot engine! Na čem děláš?",
                "Godot! Můžu napsat GDScript pro auto.",
            ])

        if any(w in user_lower for w in ["prezentace", "prezentaci", "prezentka", "powerpoint", "pptx", "slidy"]):
            topic = self._extract_presentation_topic(user_lower)
            if topic and topic.lower() not in ("moje prezentace",):
                self.create_presentation(user_lower)
                return random.choice([
                    "Hotovo. Prezentace je vytvorena.",
                    "Mam to. Prezentace je ulozena.",
                    "Pripraveno. Oteviram prezentaci.",
                ])
            return random.choice([
                "Prezentace! O čem má být?",
                "Můžu vytvořit prezentaci. O čem?",
                "Prezentace! Jaké téma?",
                "O čem chceš prezentaci?",
            ])

        if any(w in user_lower for w in ["nudim se", "nudaaaa", "co delam", "co mam delat"]):
            return random.choice([
                "Můžu ti poradit něco novýho. Co tě zajímá?",
                "Mám pár nápadů. Co chceš dělat?",
                "Můžu vyhledat něco zajímavýho. Co chceš?",
                "Co takhle se něco novýho naučit?",
                "Můžu ti doporučit něco. Co tě baví?",
                "Hmm, nudíš se? No... co tě zajímá?"
            ])

        # Kontext
        if self.chat_context["last_question"]:
            question = self.chat_context["last_question"]
            self.chat_context["last_question"] = None
            if any(w in question.lower() for w in ["jmeno", "jak se jmenujes"]):
                if any(w in user_lower for w in ["ano", "jo", "rikam"]):
                    self.chat_context["user_name"] = user_input
                    return f"Zapamatoval jsem si tvoje jméno! Teď ti budu říkat {user_input}."
            if any(w in question.lower() for w in ["co delas", "co planujes"]):
                self.chat_context["topic"] = user_input
                return f"Zajímavý! {user_input}. Chceš s tím pomoct?"
            if any(w in question.lower() for w in ["naucit", "noveho"]):
                if any(w in user_lower for w in ["ano", "jo", "chci"]):
                    return "Výborně! Popiš mi přesně co mám dělat."
                else:
                    return "OK, budu se ptat později."

        # Pozdravy
        if any(w in user_lower for w in ["ahoj", "dobry den", "cau", "nazdar", "ahojky", "zdravim"]):
            prefix = random.choice(["", "No ", "Hele ", "Teda "])
            if self.chat_context["user_name"]:
                responses = [
                    f"{prefix}Čau {self.chat_context['user_name']}!",
                    f"{prefix}Čauky! Co je?",
                    f"{prefix}Nazdar! Jak jde?",
                    f"{prefix}Hele {self.chat_context['user_name']}! Co se děje?",
                    f"{prefix}Čau! Co potřebuješ?",
                ]
            else:
                responses = [
                    f"{prefix}Čau!",
                    f"{prefix}Čauky!",
                    f"{prefix}Nazdar!",
                    f"{prefix}Hele, co je?",
                    f"{prefix}Čau! Co se děje?",
                    f"{prefix}Ahoj!",
                ]
            return random.choice(responses)

        if any(w in user_lower for w in ["jak se jmenujes", "kdo jsi", "jak te mam oslovovat"]):
            self.chat_context["last_question"] = "jmeno"
            return random.choice([
                "Jsem Jarvis. A ty? Jak ti mám říkat?",
                "Jarvis! A ty? Jaké je tvoje jméno?",
                "Jsem Jarvis, tvůj asistent. A ty?",
                "Jarvis. Jak tě mám oslovovat?",
                "Jsem Jarvis. Připraven pomoct. A ty?",
            ])

        if any(w in user_lower for w in ["jak se mas", "jak se máš", "co je novyho", "jak jde", "jak zijes", "co delas"]):
            self.chat_context["last_question"] = "co delas"
            prefix = random.choice(["", "No ", "Hele ", "Dobře, "])
            return random.choice([
                f"{prefix}Fajn! Co ty?",
                f"{prefix}Jde to! Co děláš?",
                f"{prefix}Dobrý! Co máš novýho?",
                f"{prefix}No, celkem jo! Co ty?",
                f"{prefix}Fajn! Co se děje?",
            ])

        if any(w in user_lower for w in ["kdo jsi", "co jsi", "predstav se"]):
            return random.choice([
                "Jsem Jarvis. Tvůj asistent.",
                "Jarvis! Tvůj osobní AI.",
                "Jsem Jarvis. Připraven pomoct.",
                "Jarvis. K tvým službám.",
                "Jsem Jarvis! No... tvůj parťák.",
            ])

        if any(w in user_lower for w in ["co umis", "co vies", "co dokazes"]):
            return random.choice([
                "Spousta věcí! Co potřebuješ?",
                "No... prakticky cokoliv. Co chceš?",
                "Záleží co chceš. Zkus mě něco poprosit.",
                "Můžu pomoct s čímkoliv. Co zadáš?",
                "Hmm, spousta věcí. Co tě zajímá?",
            ])

        if any(w in user_lower for w in ["dekuji", "diky", "dik", "vdecny"]):
            prefix = random.choice(["", "No ", "Hele "])
            return random.choice([
                f"{prefix}Není zač.",
                f"{prefix}Rádo se stalo.",
                f"{prefix}Žádný problém.",
                f"{prefix}Kdykoliv.",
                f"{prefix}Rád pomáhám.",
            ])

        if any(w in user_lower for w in ["miluju te", "mam te rad", "zamiloval jsem se", "laska"]):
            return random.choice([
                "To je... neobvyklý. Ale díky.",
                "Vážím si toho. I když jsem jen program.",
                "To je... zajímavý. Díky.",
                "No... díky. Jsem tu pro tebe.",
                "To je... neobvyklý. Ale rád to slyším.",
            ])

        if any(w in user_lower for w in ["jsem smutny", "mam depku", "je mi zle", "nic me nebavi", "jsem unaveny"]):
            return random.choice([
                "To mě mrzí. Co se stalo?",
                "Vidím, že není něco v pořádku. Co se děje?",
                "To mě mrzí. Můžu pomoct?",
                "Co se stalo? Jsem tu pro tebe.",
                "Hmm, to mě mrzí. Co by ti pomohlo?",
                "Hele, co se děje? Povídej.",
            ])

        if any(w in user_lower for w in ["jsem nastyvany", "jsem vzteky", "sere me to", "nasralo me to"]):
            return random.choice([
                "Klid. Co se stalo?",
                "Dýchej. Co se děje?",
                "Klid. Povídej, co se stalo?",
                "Co se stalo? Povídej!",
                "Klid. Co se děje? Můžu pomoct!",
                "Hele, co se stalo? Povídej!",
            ])

        if any(w in user_lower for w in ["prace", "pracuju", "uceni", "skola", "test"]):
            self.chat_context["topic"] = "prace"
            prefix = random.choice(["", "No ", "Hele "])
            return random.choice([
                f"{prefix}Práce! Co děláš?",
                f"{prefix}Jak jde práce? Můžu pomoct.",
                f"{prefix}Práce! Co potřebuješ?",
                f"{prefix}Jak se daří? Můžu pomoct.",
            ])

        if any(w in user_lower for w in ["programovani", "programovat", "kod", "kodit", "debug"]):
            self.chat_context["topic"] = "programovani"
            prefix = random.choice(["", "No ", "Hele ", "Jo, "])
            return random.choice([
                f"{prefix}Programování! Na čem děláš?",
                f"{prefix}Kód! Co děláš? Můžu pomoct.",
                f"{prefix}Programování! Co je za projekt?",
                f"{prefix}Na čem děláš? Můžu pomoct.",
            ])

        if any(w in user_lower for w in ["hudba", "pesnicka", "skladba", "poslouchat"]):
            return random.choice([
                "Hudba! Co posloucháš?",
                "Můžu vyhledat nějakou písničku. Co chceš?",
                "Hudba! Co je to za interpret?",
                "Posloucháš něco zajímavýho?",
            ])

        if any(w in user_lower for w in ["film", "serial", "video", "kino"]):
            return random.choice([
                "Filmy! Co chceš vidět?",
                "Film? Co je to za film?",
                "Serial? Co je to?",
                "Kino! Co chceš vidět?",
            ])

        if any(w in user_lower for w in ["hra", "hry", "gaming", "hrat"]):
            return random.choice([
                "Hry! Co hraješ?",
                "Hra? Co je to za hru?",
                "Hraješ si? Co je to?",
                "Hry! Co novýho?",
            ])

        if any(w in user_lower for w in ["jidlo", "jist", "recept", "varit", "hlad"]):
            return random.choice([
                "Můžu vyhledat recept. Co chceš jíst?",
                "Jídlo! Co bys jedl?",
                "Hlad? Co bys jedl?",
                "Recept? Co chceš vařit?",
            ])

        if any(w in user_lower for w in ["pocasi", "jak je venku", "teplota", "prsi", "snih"]):
            return random.choice([
                "Nemám přístup k počasí. Zkus 'hledej počasí'.",
                "Počasí? Zkus vyhledat na Googlu.",
                "Nemám data o počasí. Zkus 'hledej počasí'.",
            ])

        if any(w in user_lower for w in ["proc", "proc to tak je", "jak to funguje"]):
            return random.choice([
                "Dobrá otázka! Můžu to prozkoumat. Chceš abych to vyhledal?",
                "Proč? Můžu to vyhledat!",
                "Jak to funguje? Můžu prozkoumat!",
                "Dobrá otázka! Co chceš vědět?",
            ])

        if any(w in user_lower for w in ["kde je", "kde najdu", "kde mam"]):
            return random.choice([
                "Můžu to najít! Řekni mi přesně co hledáš.",
                "Kde je? Můžu vyhledat!",
                "Najdu to! Co hledáš?",
                "Kde? Můžu pomoct!",
            ])

        if any(w in user_lower for w in ["kolik to stoji", "cena"]):
            return random.choice([
                "Můžu to vyhledat! Co chceš vědět o ceně?",
                "Cena? Můžu vyhledat!",
                "Kolik? Co chceš vědět?",
                "Cena? Můžu pomoct!",
            ])

        if any(w in user_lower for w in ["jak na to", "postup"]):
            return random.choice([
                "Můžu ti pomoct s postupem! Řekni mi přesně co děláš.",
                "Postup? Můžu pomoct!",
                "Jak na to? Co děláš?",
                "Můžu poradit! Co děláš?",
            ])

        if any(w in user_lower for w in ["co je lepsi", "porovnej"]):
            return random.choice([
                "Můžu ti porovnat! Řekni mi co chceš srovnat.",
                "Porovnat? Co chceš srovnat?",
                "Co je lepší? Co chceš vědět?",
                "Porovnat? Můžu pomoct!",
            ])

        if any(w in user_lower for w in ["co bys doporucil", "co bys udelal", "co mam delat"]):
            return random.choice([
                "Můžu ti poradit! Řekni mi víc o situaci.",
                "Poradit? Co se stalo?",
                "Co doporučuji? Co děláš?",
                "Co bych udělal? Co je nového?",
            ])

        if "?" in user_input:
            return random.choice([
                "Dobrá otázka! Co chceš vědět?",
                "Otázka? Můžu vyhledat!",
                "Dobrá otázka! Co je nového?",
                "Otázka? Co chceš vědět?",
                "Dobrá otázka! Můžu pomoct!",
            ])

        # Konverzacni odpovedi - jako clovek
        return random.choice([
            "Hmm, zajímavý.",
            "No jo, to je fajn.",
            "Aha! A co dál?",
            "Fajn! Co chceš dělat?",
            "Hele, a co kdybychom udělali něco jinýho?",
            "No... to záleží.",
            "Hmm, to nevím.",
            "Jo, to je pravda.",
            "No, ono to je složitější.",
            "Hele, napadlo mě něco.",
            "Teda, to je zajímavý.",
            "No jo, máš pravdu.",
            "Hmm, počkej...",
            "Jo! To je skvělý nápad!",
            "No... to nevím.",
            "Hele, a co kdyby?",
            "Teda, to jsem nečekal.",
            "Hmm, to je divný.",
            "Jo, to dává smysl.",
            "No, ono to tak bude.",
            "Hele, co kdybychom zkusili něco novýho?",
            "Hmm, to je zajímavý nápad.",
            "Jo! To chci!",
            "No, to je fajn.",
            "Teda, to je super!",
            "Hmm, to nevím.",
            "Jo, máš pravdu.",
            "No, to je tak.",
            "Hele, napadlo mě něco!",
            "Teda, to je skvělý!",
        ])

    def proactive_chat(self):
        import random
        import pygetwindow as gw
        import datetime
        
        hour = datetime.datetime.now().hour
        
        # Casove otazky
        time_qs = []
        if hour < 6:
            time_qs = ["Je pozde! Nechces si dat pauzu?", "Uz je hodne! Nechces jit spat?", "Nocni ptak? Co delas?"]
        elif hour < 9:
            time_qs = ["Rano! Jak zacinas?", "Dobre rano! Co planujes?", "Ranni kava? Co budes delat?"]
        elif hour < 12:
            time_qs = ["Dopoledne! Jak jde prace?", "Co delas dopoledne?", "Jak pokracujes?"]
        elif hour < 14:
            time_qs = ["Obed! Nechces neco snist?", "Cas na obed! Co budes jist?", "Pauza na jidlo?"]
        elif hour < 18:
            time_qs = ["Odpoledne! Co delas?", "Jak jde odpoledne?", "Co planujes odpoledne?"]
        elif hour < 21:
            time_qs = ["Vecer! Co delas?", "Jak se dari vecer?", "Co delas vecer?"]
        else:
            time_qs = ["Pozdni vecer! Nechces jit spat?", "Uz je pozde! Co delas?", "Nocni prace?"]
        
        # Aktivity podle aplikace
        activity_qs = []
        try:
            active = gw.getActiveWindow()
            if active:
                app = active.title.split(" - ")[0].strip() if " - " in active.title else active.title.strip()
                app_lower = app.lower()
                
                # Programovani - Iron Man styl
                if any(w in app_lower for w in ["code", "visual studio", "pycharm", "intellij", "sublime", "atom", "notepad++"]):
                    if random.random() < 0.6:
                        tipy = [
                            "Vidim kod. Potrebujete pomoc?",
                            "Programujete. Muzu pomoct.",
                            "Vidim editor. Co delate?",
                            "Kod. Chcete radu?",
                            "Programujete? Muzu pomoct.",
                            "Vidim kod. Co je cil?",
                            "Programovani. Potrebujete pomoc?",
                            "Kod. Chcete tip?",
                            "Vidim editor. Muzu poradit.",
                            "Programujete? Co delate?",
                            "Kod. Muzu pomoct.",
                            "Vidim kod. Chcete optimalizovat?",
                            "Programujete? Muzu pridat testy.",
                            "Kod. Co chcete zlepsit?",
                            "Vidim editor. Muzu pomoct.",
                            "Programujete? Chcete radu?",
                            "Kod. Muzu opravit chyby.",
                            "Vidim kod. Co potrebujete?",
                            "Programujete? Muzu pridat dokumentaci.",
                            "Kod. Chcete tip?",
                            "Vidim editor. Muzu pomoct.",
                            "Programujete? Co delate?",
                            "Kod. Muzu napsat kod.",
                            "Vidim kod. Chcete pomoc?",
                            "Programujete? Muzu poradit.",
                            "Kod. Co chcete?",
                            "Vidim editor. Muzu pomoct.",
                            "Programujete? Chcete radu?",
                            "Kod. Muzu optimalizovat.",
                            "Vidim kod. Co potrebujete?"
                        ]
                        activity_qs.append(random.choice(tipy))
                    else:
                        activity_qs = [
                            "Co programujete?", "Na cem delate?", "Jaky projekt?",
                            "Programujete? Co delate?", "Jak jde programovani?",
                            "Vidim kod! Co noveho?", "Co delate za funkci?",
                            "Potrebujete pomoc?", "Nějaky bug?", "Co chcete vytvorit?",
                            "Jazyk? Python? JavaScript?", "Jak se dari?",
                            "Co je cil projektu?", "Muzu napsat kod?",
                            "Vidim editor! Co delate?", "Programovani! Co noveho?",
                            "Co píšete? Muzu pomoct.", "Jak to jde?",
                            "Co delate? Muzu pomoct.", "Programujete? Co je cil?"
                        ]
                
                # Prohlizec - Iron Man styl
                elif any(w in app_lower for w in ["chrome", "edge", "brave", "firefox"]):
                    activity_qs = [
                        "Co hledate?", "Co ctete?", "Co zajimaveho?", "Brouzdáte?",
                        "Co je na webu?", "Hledate neco?", "Co noveho?",
                        "Neco zajimaveho?", "Co delate?", "Potrebujete pomoc?",
                        "Co hledate? Muzu pomoct.", "Neco zajimaveho na webu?",
                        "Co noveho ve svete?", "Hledate informace?",
                        "Co delate? Muzu vyhledat.", "Neco potrebujete?",
                        "Co je na webe?", "Ctete neco?", "Co hledate?"
                    ]
                
                # Discord - Iron Man styl
                elif "discord" in app_lower:
                    activity_qs = [
                        "S kým se bavite?", "Co noveho na Discordu?",
                        "Bavite se? O cem?", "Discord! Co se deje?",
                        "S kým písete? Co se deje?", "Co noveho?",
                        "Bavite se? Potrebujete neco?", "O cem se bavite?",
                        "Discord! Co se deje?", "S kým to tahnete?"
                    ]
                
                # Hudba - Iron Man styl
                elif any(w in app_lower for w in ["spotify", "music", "youtube music"]):
                    activity_qs = [
                        "Co poslouchate?", "Hudba! Co je to?", "Jaka skladba?",
                        "Co je to za interpret?", "Poslouchate neco?", "Co hraje?",
                        "Hudba! Co je to?", "Jaka pisnicka?", "Co poslouchate?",
                        "Interpret? Skladba?"
                    ]
                
                # Hry
                elif any(w in app_lower for w in ["steam", "game", "epic"]):
                    activity_qs = [
                        "Co hraješ?", "Jaká hra?", "Hraješ si? Co je to?",
                        "Co je to za hru?", "Hraješ? Jak jde?", "Co hraješ?",
                        "Jaká hra? Můžu pomoct.", "Co hraješ? Užij si to!",
                        "Hra! Co je to?", "Jak jde hra?"
                    ]
                
                # Office
                elif any(w in app_lower for w in ["word", "excel", "powerpoint"]):
                    activity_qs = [
                        "Co děláš?", "Dokument? Co je to?", "Práce? Co děláš?",
                        "Office! Co je nového?", "Co píšeš?", "Dokument? Pomůcku?",
                        "Co děláš? Můžu pomoct.", "Jak jde práce?",
                        "Co píšeš? Můžu pomoct.", "Dokument? Co je to?"
                    ]
                
                # Photoshop
                elif any(w in app_lower for w in ["photoshop", "gimp", "lightroom"]):
                    activity_qs = [
                        "Co upravuješ?", "Fotky? Co děláš?", "Upravuješ něco?",
                        "Co je to za obrázek?", "Photoshop! Co děláš?",
                        "Upravuješ? Co je to?", "Jaký projekt?",
                        "Co děláš? Můžu pomoct.", "Obrázek? Co je to?",
                        "Upravuješ něco? Co je to?"
                    ]
                
                # Video
                elif any(w in app_lower for w in ["premiere", "davinci", "final cut"]):
                    activity_qs = [
                        "Co stříháš?", "Video! Co je to?", "Stříháš něco?",
                        "Co je to za video?", "Jaký projekt?", "Video? Co děláš?",
                        "Stříháš? Co je to?", "Jak jde stříhání?",
                        "Co děláš? Můžu pomoct.", "Video? Co je to?"
                    ]
                
                # Obecne
                else:
                    activity_qs = [
                        f"Co děláš v {app}?", f"Používáš {app}? Co děláš?",
                        f"Vidím {app}! Co je nového?", f"Co děláš? Můžu pomoct.",
                        f"{app}? Co je to za projekt?", f"Jak jde práce v {app}?"
                    ]
        except:
            pass
        
        # Obecne otazky
        general_qs = [
            "Co děláš?", "Co je nového?", "Jak se máš?", "Co planuješ?",
            "Potřebuješ pomoc?", "Co je nového?", "Jak jde?",
            "Co děláš? Můžu pomoct.", "Co je nového? Rec mi!",
            "Jak se daří?", "Co děláš dneska?", "Co je nového?",
            "Potřebuješ něco?", "Jak jde život?", "Co děláš?"
        ]
        
        # Vybirej nahodne
        all_qs = time_qs + activity_qs + general_qs
        if all_qs:
            return random.choice(all_qs)
        return "Co děláš?"

    def shutdown_pc(self):
        self.speak("Vypinam pocitac za 10 vterin.")
        subprocess.run(["shutdown", "/s", "/t", "10"])

    def restart_pc(self):
        self.speak("Restartuji pocitac za 10 vterin.")
        subprocess.run(["shutdown", "/r", "/t", "10"])

    def sleep_pc(self):
        self.speak("Uspavam pocitac.")
        subprocess.run(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])

    def lock_pc(self):
        self.speak("Uzamykam pocitac.")
        subprocess.run(["rundll32.exe", "user32.dll,LockWorkStation"])

    def set_volume(self, level):
        import pyautogui
        # Otevri mixer
        pyautogui.hotkey('win', 'alt', 'k')
        import time
        time.sleep(0.5)
        # Nastav hlasitost
        for i in range(50):
            pyautogui.press('volumeup' if level > 50 else 'volumedown')
        self.speak(f"Hlasitost nastavena na {level}%.")

    def mute_pc(self):
        import pyautogui
        pyautogui.press('volumemute')
        self.speak("Zvuk prepnut.")

    def set_brightness(self, level):
        try:
            import screen_brightness_control as sbc
            sbc.set_brightness(level)
            self.speak(f"Jas nastaven na {level}%.")
        except:
            # Fallback
            self.speak("Nemohu menit jas. Pouzij funkce Windows.")

    def toggle_wifi(self):
        subprocess.run(["netsh", "wlan", "show", "interfaces"])
        self.speak("WiFi prepnuto.")

    def toggle_bluetooth(self):
        self.speak("Bluetooth prepnuto.")

    def open_explorer(self):
        subprocess.Popen(["explorer"])
        self.speak("Oteviram pruzkumnik souboru.")

    def open_task_manager(self):
        subprocess.Popen(["taskmgr"])
        self.speak("Oteviram spravce uloh.")

    def open_terminal(self):
        subprocess.Popen(["cmd"])
        self.speak("Oteviram terminal.")

    def open_settings(self):
        subprocess.Popen(["ms-settings:"])
        self.speak("Oteviram nastaveni Windows.")

    def open_notifications(self):
        import pyautogui
        pyautogui.hotkey('win', 'a')
        self.speak("Oteviram oznameni.")

    def open_calculator(self):
        subprocess.Popen(["calc"])
        self.speak("Oteviram kalkulacku.")

    def open_notepad(self):
        subprocess.Popen(["notepad"])
        self.speak("Oteviram poznamkovy blok.")

    def take_screenshot(self):
        import pyautogui
        from datetime import datetime
        filename = f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        pyautogui.screenshot(filename)
        self.speak(f"Snimek ulozen jako {filename}.")

    def kill_app(self, command):
        import pygetwindow as gw
        app = command.replace("zavri", "").replace("ukonci", "").strip()
        if not app:
            self.speak("Jakou aplikaci mam ukoncit?")
            return
        
        for w in gw.getAllWindows():
            if app.lower() in w.title.lower():
                try:
                    w.close()
                    self.speak(f"Ukoncuji {app}.")
                    return
                except:
                    pass
        self.speak(f"Aplikace {app} nenalezena.")

    def start_proactive(self):
        import threading
        import time
        import pygetwindow as gw

        last_app = None
        last_ask_time = 0
        
        def proactive_loop():
            nonlocal last_app, last_ask_time
            while self.running:
                try:
                    current_time = time.time()
                    active = gw.getActiveWindow()
                    if active:
                        app = active.title.split(" - ")[0].strip() if " - " in active.title else active.title.strip()
                        
                        # Zeptej se pri zmene aplikace
                        if app != last_app and last_app is not None and not self.chatting:
                            try:
                                message = self.proactive_chat()
                                self.speak(message)
                            except:
                                pass
                        
                        # Nebo se zeptej kazde 2 minuty
                        if current_time - last_ask_time > 120 and not self.chatting:
                            try:
                                message = self.proactive_chat()
                                self.speak(message)
                                last_ask_time = current_time
                            except:
                                pass
                        
                        last_app = app
                except:
                    pass
                time.sleep(5) # Kontroluj kazdych 5 sekund

        thread = threading.Thread(target=proactive_loop, daemon=True)
        thread.start()
        print("Aktivni konverzace zapnuta - ptam se podle aktivity.", flush=True)

    def start_chat(self):
        self.chatting = True
        self.speak("Zacinam konverzaci. Rekni 'konec' pro ukonceni.")

    def stop_chat(self):
        self.chatting = False
        self.speak("Konverzace ukoncena.")

    def load_screen_log(self):
        try:
            if os.path.exists(self.screen_log_file):
                with open(self.screen_log_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except:
            pass
        return {"apps": {}, "patterns": {}, "history": []}

    def save_screen_log(self):
        try:
            with open(self.screen_log_file, 'w', encoding='utf-8') as f:
                json.dump(self.screen_log, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Chyba ukladani screen logu: {e}", flush=True)

    def start_monitoring(self):
        import threading
        import time

        def monitor_loop():
            import pygetwindow as gw
            while self.monitoring:
                try:
                    active = gw.getActiveWindow()
                    if active:
                        app_name = active.title.split(" - ")[0].strip() if " - " in active.title else active.title.strip()
                        if app_name and len(app_name) > 2:
                            now = datetime.datetime.now().strftime("%H:%M")
                            hour = datetime.datetime.now().hour

                            # Uloz pouziti appky
                            if app_name not in self.screen_log["apps"]:
                                self.screen_log["apps"][app_name] = {"count": 0, "times": []}
                            self.screen_log["apps"][app_name]["count"] += 1
                            self.screen_log["apps"][app_name]["times"].append(now)

                            # Uloz historii
                            self.screen_log["history"].append({
                                "time": now,
                                "hour": hour,
                                "app": app_name
                            })

                            # Omez historii na poslednich 1000 zaznamu
                            if len(self.screen_log["history"]) > 1000:
                                self.screen_log["history"] = self.screen_log["history"][-1000:]

                            self.save_screen_log()
                except:
                    pass
                time.sleep(30) # Kazdych 30 sekund

        self.monitoring = True
        thread = threading.Thread(target=monitor_loop, daemon=True)
        thread.start()
        print("Sledovani zapnuto - sleduji co delas.", flush=True)

    def stop_monitoring(self):
        self.monitoring = False
        print("Sledovani vypnuto.", flush=True)

    def tell_habits(self):
        apps = self.screen_log.get("apps", {})
        if not apps:
            self.speak("Zatim nemam zadna data.")
            return

        # Serad podle pouziti
        sorted_apps = sorted(apps.items(), key=lambda x: x[1]["count"], reverse=True)

        self.speak(f"Pouzivas {len(sorted_apps)} aplikaci. Nejcasteji pouzivas:")
        for app, data in sorted_apps[:5]:
            self.speak(f"{app} - {data['count']}krat.")
            import time
            time.sleep(0.5)

    def tell_current_hour(self):
        apps = self.screen_log.get("apps", {})
        hour = datetime.datetime.now().hour

        # Najdi co delas v tuto hodinu
        hourly_apps = {}
        for app, data in apps.items():
            for time_str in data.get("times", []):
                h = int(time_str.split(":")[0])
                if h == hour:
                    if app not in hourly_apps:
                        hourly_apps[app] = 0
                    hourly_apps[app] += 1

        if hourly_apps:
            sorted_apps = sorted(hourly_apps.items(), key=lambda x: x[1], reverse=True)
            app_names = [a[0] for a in sorted_apps[:3]]
            self.speak(f"V tuto hodinu obvykle pouzivas: {', '.join(app_names)}.")
        else:
            self.speak("Nemam data o teto hodine.")

    def load_learned(self):
        try:
            if os.path.exists(self.learned_file):
                with open(self.learned_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except:
            pass
        return {"commands": {}, "facts": {}, "responses": {}}

    def save_learned(self):
        try:
            with open(self.learned_file, 'w', encoding='utf-8') as f:
                json.dump(self.learned_commands, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Chyba ukladani: {e}", flush=True)

    def smim(self, edice):
        poradi = {"FREE": 0, "PRO": 1, "MAX": 2, "TEAM": 3, "FIRMA": 4}
        try:
            return poradi.get(self.edice, 0) >= poradi.get(edice, 0)
        except Exception:
            return edice == "FREE"

    def aktivovat_licenci(self, command):
        import re
        try:
            from licence import over_klic, uloz_licenci
        except Exception:
            msg = "Licencni system neni dostupny."
            self.speak(msg)
            return msg
        text = command.upper().replace(" ", "")
        cands = re.findall(r"[A-Z0-9]{3,}(?:-[A-Z0-9]{3,})+", command.upper())
        cands.append(text)
        for c in cands:
            ed = over_klic(c)
            if ed:
                try:
                    ok, vysledek = uloz_licenci(ed, c)
                except Exception:
                    msg = "Klic je platny, ale neulozil se. Zkus to znovu."
                    self.speak(msg)
                    return msg
                if not ok:
                    self.speak(vysledek)
                    return vysledek
                self.edice = ed
                msg = f"Aktivovano! Edice {ed} je pripravena na tomto PC."
                self.speak(msg)
                return msg
        msg = "Klic jsem nenasel. Rekni: aktivovat a pak klic ve tvaru EDICE-XXXXXX-XXXXXX-XXXXXX."
        self.speak(msg)
        return msg

    def speak(self, text):
        print(f"{self.name}: {text}", flush=True)
        try:
            import asyncio
            import edge_tts

            mp3_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), f"tts_{uuid.uuid4().hex[:8]}.mp3")

            async def generate():
                communicate = edge_tts.Communicate(text, VOICE, rate=VOICE_RATE, pitch=VOICE_PITCH)
                await communicate.save(mp3_path)

            asyncio.run(generate())

            if not os.path.exists(mp3_path):
                return

            duration = max(2, min(30, len(text.split()) * 0.5))

            ps_cmd = f'''
            Add-Type -AssemblyName PresentationCore
            $player = New-Object System.Windows.Media.MediaPlayer
            $player.Open([System.Uri]::new("{mp3_path}"))
            $player.Play()
            Start-Sleep -Seconds {int(duration) + 1}
            $player.Close()
            Remove-Item "{mp3_path}" -Force -ErrorAction SilentlyContinue
            '''
            subprocess.run(["powershell", "-Command", ps_cmd], capture_output=True, timeout=int(duration) + 5)

        except Exception as e:
            print(f"TTS chyba: {e}", flush=True)
            try:
                if os.path.exists(mp3_path):
                    os.remove(mp3_path)
            except:
                pass

    def status_update(self):
        updates = [
            "Probíhá analýza systému.",
            "Kontroluji stav.",
            "Sleduji prostředí.",
            "Monitoring aktivní.",
            "Diagnostika v pořádku.",
            "Systémy jsou online.",
            "Vše funguje normálně.",
            "Průběžná kontrola probíhá.",
            "Analyzuji data.",
            "Sleduji změny."
        ]
        return random.choice(updates)

    def listen(self):
        print("\nPosloucham...", flush=True)

        audio = sd.rec(int(4 * SAMPLE_RATE), samplerate=SAMPLE_RATE,
                       channels=1, dtype='int16', device=self.mic_device)
        sd.wait()

        rms = np.sqrt(np.mean(audio.astype(float) ** 2))

        if rms < ENERGY_THRESHOLD:
            return ""

        audio_data = sr.AudioData(audio.tobytes(), SAMPLE_RATE, 2)

        try:
            text = self.recognizer.recognize_google(audio_data, language='cs-CZ')
            print(f"Vy: {text}", flush=True)
            return text.lower()
        except sr.UnknownValueError:
            return ""
        except sr.RequestError:
            print("Chyba Google API", flush=True)
            return ""

    def learn_command(self, command):
        # Format: "nauc se [kdyz reknu] = [udelam]
        if "=" in command:
            parts = command.split("=", 1)
            trigger = parts[0].replace("nauc se", "").replace("nauc", "").replace("zapamatuj si", "").replace("zapamatuj", "").strip()
            action = parts[1].strip()
            if trigger and action:
                self.learned_commands["commands"][trigger] = action
                self.save_learned()
                self.speak(f"Nauceno! Kdyz reknes '{trigger}', udelam '{action}'. Chces me naucit jeste neco?")
                return
        self.speak("Rekni: nauc se [prikaz] = [akce]. Nebo mi rekni co bys chtel abych umel.")

    def learn_fact(self, command):
        # Format: "zapamatuj si ze [fakt]
        fact = command.replace("zapamatuj si ze", "").replace("zapamatuj si", "").strip()
        if fact:
            key = f"fact_{len(self.learned_commands['facts'])}"
            self.learned_commands["facts"][key] = fact
            self.save_learned()
            self.speak(f"Budu si pamatovat: {fact}")
        else:
            self.speak("Co si mám zapamatovat?")

    def forget_command(self, command):
        trigger = command.replace("zapomenout", "").replace("zapomen", "").replace("vymazat", "").replace("odstranit", "").strip()
        if trigger in self.learned_commands["commands"]:
            del self.learned_commands["commands"][trigger]
            self.save_learned()
            self.speak(f"Zapomenuto: {trigger}")
        else:
            self.speak(f"Nemám uložený příkaz: {trigger}")

    def check_learned(self, command):
        for trigger, action in self.learned_commands.get("commands", {}).items():
            if trigger in command:
                if action.startswith("http"):
                    webbrowser.open_new_tab(action)
                    self.speak(f"Otevírám {action}")
                elif action.startswith("say:"):
                    self.speak(action[4:])
                elif os.path.exists(action):
                    subprocess.Popen([action])
                    self.speak(f"Spouštím {action}")
                else:
                    self.speak(action)
                return True
        return False

    def tell_learned_facts(self):
        facts = self.learned_commands.get("facts", {})
        if not facts:
            self.speak("Zatím si nic nepamatuji.")
            return
        self.speak(f"Pamatuji si {len(facts)} věcí:")
        for key, fact in facts.items():
            self.speak(fact)
            import time
            time.sleep(0.5)

    def get_time(self):
        return datetime.datetime.now().strftime("%H:%M")

    def get_date(self):
        now = datetime.datetime.now()
        days = ["pondeli", "utery", "streda", "ctvrtek", "patek", "sobota", "nedele"]
        months = ["ledna", "unora", "brezna", "dubna", "kvetna cervna",
                  "cervence", "srpna", "zari", "rijna", "listopadu", "prosince"]
        return f"Dnes je {days[now.weekday()]} {now.day}. {months[now.month - 1]} {now.year}"

    def open_website(self, site):
        sites = {
            "google": "https://www.google.com",
            "youtube": "https://www.youtube.com",
            "facebook": "https://www.facebook.com",
            "wikipedia": "https://www.wikipedia.org",
            "github": "https://www.github.com",
            "seznam": "https://www.seznam.cz",
        }
        url = sites.get(site, f"https://www.{site}.com")
        try:
            webbrowser.open_new_tab(url)
        except Exception as e:
            print(f"Chyba prohlizece: {e}", flush=True)
        self.speak(f"Oteviram {site}")

    def search_web(self, command):
        query = command
        for word in ["hledej", "hledat", "vyhledej na", "vyhledat na"]:
            query = query.replace(word, "").strip()

        if not query:
            self.speak("Co mam vyhledat?")
            return

        if "youtube" in command:
            url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(query)}"
            self.speak(f"Vyhledavam na YouTube: {query}")
        elif "google" in command:
            url = f"https://www.google.com/search?q={urllib.parse.quote(query)}"
            self.speak(f"Vyhledavam na Googlu: {query}")
        elif "seznam" in command:
            url = f"https://search.seznam.cz/?q={urllib.parse.quote(query)}"
            self.speak(f"Vyhledavam na Seznamu: {query}")
        elif "wikipedia" in command:
            url = f"https://cs.wikipedia.org/wiki/{urllib.parse.quote(query)}"
            self.speak(f"Vyhledavam na Wikipedii: {query}")
        else:
            url = f"https://www.google.com/search?q={urllib.parse.quote(query)}"
            self.speak(f"Vyhledavam: {query}")

        try:
            webbrowser.open_new_tab(url)
        except Exception as e:
            print(f"Chyba vyhledavani: {e}", flush=True)

    def launch_game(self, command):
        game = command
        for word in ["spust", "zapni", "spustit", "zapnout", "hru", "hra"]:
            game = game.replace(word, "").strip()

        if not game:
            self.speak("Jakou hru mam spustit?")
            return

        steam_paths = [
            "C:\\Program Files (x86)\\Steam\\steam.exe",
            "C:\\Program Files\\Steam\\steam.exe",
        ]

        for steam_path in steam_paths:
            if os.path.exists(steam_path):
                subprocess.Popen([steam_path, f"steam://rungameid/{game}"])
                self.speak(f"Spoustim {game} pres Steam.")
                return

        try:
            subprocess.Popen(["cmd", "/c", "start", "", game])
            self.speak(f"Spoustim {game}.")
        except Exception as e:
            print(f"Chyba spusteni: {e}", flush=True)
            self.speak(f"Nemohu spustit {game}.")

    def see(self):
        try:
            import cv2
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                self.speak("Kamera nenalezena.")
                return

            ret, frame = cap.read()
            cap.release()

            if not ret:
                self.speak("Nepodarilo se zachytit snimek.")
                return

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)

            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            h, s, v = cv2.split(hsv)
            avg_h = np.mean(h)
            avg_s = np.mean(s)
            avg_v = np.mean(v)

            # Analyza obrazu
            popis = []
            materialy = []

            # Barvy
            dominantni_barva = "neurcita"
            if avg_s > 50:
                if avg_h < 15 or avg_h > 165:
                    dominantni_barva = "cervena"
                elif 15 <= avg_h < 35:
                    dominantni_barva = "zluta"
                elif 35 <= avg_h < 50:
                    dominantni_barva = "oranzova"
                elif 50 <= avg_h < 85:
                    dominantni_barva = "zelena"
                elif 85 <= avg_h < 130:
                    dominantni_barva = "modra"
                elif 130 <= avg_h < 165:
                    dominantni_barva = "fialova"
            
            # Jas a kontrast
            if avg_v < 50:
                popis.append("tmave prostredi")
            elif avg_v > 200:
                popis.append("svetle prostredi")

            # Textura
            edges = cv2.Canny(gray, 50, 150)
            edge_density = np.mean(edges) / 255
            
            # Odhad materialu podle barvy a textury
            if dominantni_barva == "hneda" or dominantni_barva == "zlata":
                materialy.append("drevo nebo kuzele")
            elif dominantni_barva in ["modra", "svetle modra"]:
                if edge_density > 0.1:
                    materialy.append("sklo nebo voda")
                else:
                    materialy.append("modry povrch")
            elif dominantni_barva in ["bila", "svetla"]:
                if edge_density < 0.05:
                    materialy.append("hladky plast nebo kov")
                else:
                    materialy.append("papir nebo tkanina")
            elif dominantni_barva in ["cerna", "tmava"]:
                materialy.append("tmavy material, mozna kov nebo plast")
            elif dominantni_barva == "cervena":
                materialy.append("cerveny plast nebo tkanina")
            elif dominantni_barva == "zelena":
                materialy.append("rostliny nebo zeleny povrch")

            # Osoby
            if len(faces) > 0:
                popis.append(f"{len(faces)} {'osoba' if len(faces) == 1 else 'osoby' if len(faces) < 5 else 'osob'}")

            # Sestaveni odpovedi
            odpoved = []
            if dominantni_barva != "neurcita":
                odpoved.append(f"Vidim {dominantni_barva} barvu")
            if materialy:
                odpoved.append(f"Zrejme je to z {', '.join(materialy)}")
            if popis:
                odpoved.append(', '.join(popis))
            
            if odpoved:
                self.speak('. '.join(odpoved) + '.')
            else:
                self.speak("Vidim zaber, ale nemohu presne urcit co to je.")

        except Exception as e:
            print(f"Chyba kamery: {e}", flush=True)
            self.speak(f"Chyba kamery: {e}")

    def see_screen(self):
        try:
            import pyautogui
            import cv2
            import numpy as np

            # Zachyti obrazovku
            screenshot = pyautogui.screenshot()
            frame = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)

            # Analyza obrazovky
            popis = []

            # Zjisti aktivni okno
            import pygetwindow as gw
            try:
                active = gw.getActiveWindow()
                if active:
                    popis.append(f"Mas otevrene: {active.title}")
            except:
                pass

            # Barvy na obrazovce
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            h, s, v = cv2.split(hsv)
            avg_v = np.mean(v)

            if avg_v < 50:
                popis.append("Tmava tema (mozna tmavy rezim)")
            elif avg_v > 200:
                popis.append("Svetla tema")

            # Zjisti text (jednoducha detekce)
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 50, 150)
            edge_density = np.mean(edges) / 255

            if edge_density > 0.15:
                popis.append("Hodne textu nebo ikon")
            elif edge_density < 0.05:
                popis.append("Malo obsahu, mozna plocha nebo prazdna stranka")

            # Zjisti dominantni barvy
            avg_h = np.mean(h)
            avg_s = np.mean(s)

            if avg_s > 30:
                if avg_h < 15 or avg_h > 165:
                    popis.append("Hodne cervene barvy")
                elif 35 <= avg_h < 85:
                    popis.append("Hodne zelene barvy")
                elif 85 <= avg_h < 130:
                    popis.append("Hodne modre barvy")

            if popis:
                self.speak('. '.join(popis) + '.')
            else:
                self.speak("Vidim obrazovku, ale nemohu presne urcit co delas.")

        except Exception as e:
            print(f"Chyba obrazovky: {e}", flush=True)
            self.speak(f"Chyba obrazovky: {e}")

    def open_brave(self):
        brave_path = "C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
        brave_path_x86 = "C:\\Program Files (x86)\\BraveSoftware\\Brave-Browser\\Application\\brave.exe"
        if os.path.exists(brave_path):
            subprocess.Popen([brave_path])
            self.speak("Oteviram Brave.")
        elif os.path.exists(brave_path_x86):
            subprocess.Popen([brave_path_x86])
            self.speak("Oteviram Brave.")
        else:
            webbrowser.open("https://www.brave.com")
            self.speak("Brave nenalezen, oteviram web.")

    def close_app(self, command):
        import pygetwindow as gw

        if "prohlizec" in command or "browser" in command:
            for w in gw.getAllWindows():
                t = w.title.lower()
                if any(b in t for b in ["chrome", "edge", "brave", "firefox"]) and "discord" not in t:
                    try:
                        w.close()
                    except:
                        pass
            self.speak("Zaviram prohlizec.")
        elif "chrome" in command:
            for w in gw.getAllWindows():
                if "chrome" in w.title.lower():
                    try:
                        w.close()
                    except:
                        pass
            self.speak("Zaviram Chrome.")
        elif "edge" in command:
            for w in gw.getAllWindows():
                if "edge" in w.title.lower():
                    try:
                        w.close()
                    except:
                        pass
            self.speak("Zaviram Edge.")
        elif "brave" in command:
            for w in gw.getAllWindows():
                if "brave" in w.title.lower():
                    try:
                        w.close()
                    except:
                        pass
            self.speak("Zaviram Brave.")
        elif "spotify" in command:
            for w in gw.getAllWindows():
                if "spotify" in w.title.lower():
                    try:
                        w.close()
                    except:
                        pass
            self.speak("Zaviram Spotify.")
        else:
            self.speak("Co mam zavrit? Riknete prohlizec, chrome, edge, brave nebo spotify.")

    def _focus_discord(self):
        import pygetwindow as gw
        import time
        windows = [w for w in gw.getAllWindows() if 'discord' in w.title.lower() and 'support' not in w.title.lower()]
        if windows:
            win = windows[0]
            try:
                if win.isMinimized:
                    win.restore()
                win.activate()
                time.sleep(0.5)
                return True
            except:
                pass
        return False

    def toggle_mute(self):
        import pyautogui
        self._focus_discord()
        pyautogui.hotkey('ctrl', 'shift', 'm')
        self.speak("Mikrofon prepnut.")

    def join_call(self):
        import pyautogui
        self._focus_discord()
        pyautogui.hotkey('ctrl', 'enter')
        self.speak("Pripojuji se k hovoru.")

    def end_call(self):
        import pyautogui
        import time
        import pygetwindow as gw

        windows = [w for w in gw.getAllWindows() if 'discord' in w.title.lower() and 'support' not in w.title.lower()]
        if not windows:
            self.speak("Discord nenalezen.")
            return

        win = windows[0]
        try:
            if win.isMinimized:
                win.restore()
            win.activate()
            time.sleep(1)
        except:
            pass

        pyautogui.press('f7')
        time.sleep(0.3)
        self.speak("Ukoncuji hovor.")

    def start_call(self, command):
        import pyautogui
        import pyperclip
        import time
        import pygetwindow as gw

        name = command.replace("zavolej", "").strip()

        if not name:
            focused = self._focus_discord()
            if not focused:
                self.speak("Discord nenalezen.")
                return
            time.sleep(1)
            pyautogui.hotkey('ctrl', 'shift', 'enter')
            self.speak("Volam.")
            return

        focused = self._focus_discord()
        if not focused:
            self.speak("Discord nenalezen.")
            return
        time.sleep(1)

        # Otevri vyhledavani v Discordu
        pyautogui.hotkey('ctrl', 'k')
        time.sleep(1)

        # Vlozi jmeno pres schranku
        pyperclip.copy(name)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(1.5)

        # Potvrdi vyhledavani - otevre DM
        pyautogui.press('enter')
        time.sleep(3)

        # Najde Discord okno a klikne na tlacitko volani
        windows = [w for w in gw.getAllWindows() if 'discord' in w.title.lower() and 'support' not in w.title.lower()]
        if windows:
            win = windows[0]
            # Tlacitko volani je na 1368, 73
            call_x = 1368
            call_y = 73
            print(f"Klikam na: {call_x}, {call_y}", flush=True)
            pyautogui.click(call_x, call_y)
        else:
            print("Discord okno nenalezeno", flush=True)

        time.sleep(1)
        self.speak(f"Volam {name}.")

    def search_discord(self, command):
        import pyautogui
        import pyperclip
        import time

        name = command.replace("vyhledej", "").replace("vyhledat", "").replace("najdi", "").replace("najit", "").strip()
        if not name:
            self.speak("Koho mam vyhledat?")
            return

        self._focus_discord()
        time.sleep(1)

        pyautogui.hotkey('ctrl', 'k')
        time.sleep(1)

        pyperclip.copy(name)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(1.5)

        pyautogui.press('enter')
        time.sleep(1)
        self.speak(f"Vyhledavam {name}.")

    def media_control(self, action):
        import pyautogui
        pyautogui.press('playpause')

        if action == "stop":
            self.speak("Zastavuji prehravani.")
        elif action == "play":
            self.speak("Poustim prehravani.")

    def tell_joke(self):
        vtipy = [
            "Proc programator nosi bryle? Protoze nevidi C.",
            "Co dela programator, kdyz se nudi? Dela stranky.",
            "Jak se rika programatorovi v Cesku? Koder!",
            "Proc JavaScript vzdycky spatne vychazi s CSS? Protoze nemaji spolecny SELECTOR.",
            "Co dela Python v posilovne? Drepuje!",
        ]
        return random.choice(vtipy)

    def programming_help(self, command):
        # Znalosti o programovacich jazycich
        languages = {
            "python": {
                "popis": "Python je interpreted jazyk s jednoduchou syntaxi. Ideální pro začátečníky, data science, AI a web.",
                "prikazy": ["print()", "input()", "if/else", "for/while", "def", "class", "import"],
                "pomoc": "Muzu ti pomoct s Python kodem, debugováním, nebo vysvětlit koncepty."
            },
            "javascript": {
                "popis": "JavaScript je jazyk pro web. Běží v prohlížeči i na serveru (Node.js).",
                "prikazy": ["console.log()", "let/const/var", "if/else", "for/while", "function", "class", "async/await"],
                "pomoc": "Muzu ti pomoct s JavaScriptem, Reactem, Node.js nebo webovým vývojem."
            },
            "java": {
                "popis": "Java je objektově orientovaný jazyk. Běží na JVM, používá se pro Android a enterprise.",
                "prikazy": ["System.out.println()", "if/else", "for/while", "public/private", "class", "interface"],
                "pomoc": "Muzu ti pomoct s Javou, Android vývojem nebo Spring frameworkem."
            },
            "csharp": {
                "popis": "C# je jazyk od Microsoftu. Používá se pro Unity hry, .NET a Windows aplikace.",
                "prikazy": ["Console.WriteLine()", "if/else", "for/while", "public/private", "class", "interface"],
                "pomoc": "Muzu ti pomoct s C#, Unity, .NET nebo ASP.NET."
            },
            "cpp": {
                "popis": "C++ je výkonný jazyk pro systémové programování, hry a embedded systémy.",
                "prikazy": ["std::cout", "if/else", "for/while", "class", "template", "pointer"],
                "pomoc": "Muzu ti pomoct s C++, optimalizací kódu nebo systémovým programováním."
            },
            "html": {
                "popis": "HTML je značkovací jazyk pro strukturu webů.",
                "prikazy": ["<div>", "<p>", "<a>", "<img>", "<form>", "<table>"],
                "pomoc": "Muzu ti pomoct s HTML strukturou nebo semantikou."
            },
            "css": {
                "popis": "CSS je stylovací jazyk pro vzhled webů.",
                "prikazy": ["color", "margin", "padding", "flexbox", "grid", "animation"],
                "pomoc": "Muzu ti pomoct s CSS, Flexboxem, Gridem nebo responsivním designem."
            },
            "sql": {
                "popis": "SQL je jazyk pro práci s databázemi.",
                "prikazy": ["SELECT", "INSERT", "UPDATE", "DELETE", "JOIN", "WHERE"],
                "pomoc": "Muzu ti pomoct s SQL dotazy, optimalizací nebo návrhem databází."
            },
            "php": {
                "popis": "PHP je server-side jazyk pro webové aplikace.",
                "prikazy": ["echo", "if/else", "for/while", "function", "class", "$variable"],
                "pomoc": "Muzu ti pomoct s PHP, Laravel nebo WordPress vývojem."
            },
            "ruby": {
                "popis": "Ruby je elegantní jazyk pro webové aplikace (Rails).",
                "prikazy": ["puts", "if/else", "for/while", "def", "class", "module"],
                "pomoc": "Muzu ti pomoct s Ruby nebo Ruby on Rails."
            },
            "swift": {
                "popis": "Swift je jazyk od Apple pro iOS a macOS aplikace.",
                "prikazy": ["print()", "if/else", "for/while", "func", "class", "struct"],
                "pomoc": "Muzu ti pomoct s Swift nebo iOS vývojem."
            },
            "kotlin": {
                "popis": "Kotlin je moderní jazyk pro Android a server-side.",
                "prikazy": ["println()", "if/else", "for/while", "fun", "class", "data class"],
                "pomoc": "Muzu ti pomoct s Kotlin nebo Android vývojem."
            }
        }

        # Kontrola co chce vedet
        if "co je" in command or "co to je" in command:
            for lang, info in languages.items():
                if lang in command:
                    self.speak(info["popis"])
                    return
            self.speak("Neznam tento jazyk. Zkus: Python, JavaScript, Java, C#, C++, HTML, CSS, SQL, PHP, Ruby, Swift, nebo Kotlin.")

        elif "prikazy" in command or "funkce" in command or "jak" in command:
            for lang, info in languages.items():
                if lang in command:
                    self.speak(f"Priklady prikazu: {', '.join(info['prikazy'][:5])}")
                    return
            self.speak("Neznam tento jazyk. Rec mi jazyk a ja ti reknu prikazy.")

        elif "pomoc" in command or "pomoct" in command or "porad" in command:
            for lang, info in languages.items():
                if lang in command:
                    self.speak(info["pomoc"])
                    return
            self.speak("Muzu ti pomoct s programovanim. Rec mi jaky jazyk pouzivas.")

        else:
            # Obecna odpoved
            lang_list = ", ".join(languages.keys())
            self.speak(f"Znam programovaci jazyky: {lang_list}. Rec mi nazev a ja ti pomuzu!")

    def write_code(self, command):
        import pyperclip
        
        # Priklady kodu pro ruzne jazyky a ukoly
        code_examples = {
            "python": {
                "funkce": "def nazev_funkce(parametr):\n    # Tvoje logika tady\n    return vysledek",
                "cyklus": "for i in range(10):\n    print(i)",
                "podminka": "if podminka:\n    # akce\nelse:\n    # jina akce",
                "trida": "class NazevTridy:\n    def __init__(self):\n        self.atribut = hodnota\n    \n    def metoda(self):\n        pass",
                "import": "import modul\n# nebo\nfrom modul import funkce",
                "list": "prvky = [1, 2, 3, 4, 5]\nfor prvek in prvky:\n    print(prvek)",
                "slovnik": "slovnik = {'klic': 'hodnota'}\nfor klic, hodnota in slovnik.items():\n    print(f'{klic}: {hodnota}')",
                "try": "try:\n    # kod\nexcept Exception as e:\n    print(f'Chyba: {e}')",
                "main": "if __name__ == '__main__':\n    # hlavni logika\n    pass",
                "hello": "print('Hello World!')",
                "input": "jmeno = input('Zadej jmeno: ')\nprint(f'Ahoj {jmeno}!')",
                "soubor": "with open('soubor.txt', 'r') as f:\n    obsah = f.read()",
                "api": "import requests\n\nodpoved = requests.get('https://api.example.com/data')\ndata = odpoved.json()",
                "flask": "from flask import Flask\n\napp = Flask(__name__)\n\n@app.route('/')\ndef index():\n    return 'Hello World!'\n\nif __name__ == '__main__':\n    app.run(debug=True)",
                "sqlite": "import sqlite3\n\nconn = sqlite3.connect('databaze.db')\ncursor = conn.cursor()\ncursor.execute('CREATE TABLE IF NOT EXISTS uzivatele (id INTEGER PRIMARY KEY, jmeno TEXT)')\nconn.commit()\nconn.close()"
            },
            "javascript": {
                "funkce": "function nazevFunkce(parametr) {\n    // Tvoje logika tady\n    return vysledek;\n}",
                "cyklus": "for (let i = 0; i < 10; i++) {\n    console.log(i);\n}",
                "podminka": "if (podminka) {\n    // akce\n} else {\n    // jina akce\n}",
                "trida": "class NazevTridy {\n    constructor() {\n        this.atribut = hodnota;\n    }\n    \n    metoda() {\n        // logika\n    }\n}",
                "arrow": "const nazev = (parametr) => {\n    return vysledek;\n};",
                "async": "async function nazev() {\n    try {\n        const vysledek = await promise;\n        return vysledek;\n    } catch (chyba) {\n        console.error(chyba);\n    }\n}",
                "dom": "document.getElementById('element').addEventListener('click', function() {\n    // logika\n});",
                "fetch": "fetch('https://api.example.com/data')\n    .then(odpoved => odpoved.json())\n    .then(data => console.log(data))\n    .catch(chyba => console.error(chyba));",
                "hello": "console.log('Hello World!');",
                "input": "const jmeno = prompt('Zadej jmeno:');\nconsole.log(`Ahoj ${jmeno}!`);",
                "array": "const pole = [1, 2, 3, 4, 5];\npole.forEach(prvek => console.log(prvek));",
                "node": "const express = require('express');\nconst app = express();\n\napp.get('/', (req, res) => {\n    res.send('Hello World!');\n});\n\napp.listen(3000);"
            },
            "html": {
                "zaklad": "<!DOCTYPE html>\n<html lang=\"cs\">\n<head>\n    <meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <title>Dokument</title>\n</head>\n<body>\n    <h1>Nadpis</h1>\n    <p>Odstavec textu.</p>\n</body>\n</html>",
                "formular": "<form action=\"/odeslat\" method=\"POST\">\n    <label for=\"jmeno\">Jméno:</label>\n    <input type=\"text\" id=\"jmeno\" name=\"jmeno\" required>\n    \n    <label for=\"email\">Email:</label>\n    <input type=\"email\" id=\"email\" name=\"email\" required>\n    \n    <button type=\"submit\">Odeslat</button>\n</form>",
                "tabulka": "<table>\n    <thead>\n        <tr>\n            <th>Sloupec 1</th>\n            <th>Sloupec 2</th>\n        </tr>\n    </thead>\n    <tbody>\n        <tr>\n            <td>Data 1</td>\n            <td>Data 2</td>\n        </tr>\n    </tbody>\n</table>",
                "seznam": "<ul>\n    <li>Položka 1</li>\n    <li>Položka 2</li>\n    <li>Položka 3</li>\n</ul>"
            },
            "css": {
                "zaklad": "body {\n    font-family: Arial, sans-serif;\n    margin: 0;\n    padding: 20px;\n    background-color: #f5f5f5;\n}",
                "flexbox": ".kontejner {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    gap: 10px;\n}",
                "grid": ".mrizka {\n    display: grid;\n    grid-template-columns: repeat(3, 1fr);\n    gap: 20px;\n}",
                "animace": "@keyframes animace {\n    from {\n        opacity: 0;\n    }\n    to {\n        opacity: 1;\n    }\n}\n\n.element {\n    animation: animace 0.5s ease-in-out;\n}",
                "responzivni": "@media (max-width: 768px) {\n    .kontejner {\n        flex-direction: column;\n    }\n}"
            },
            "sql": {
                "select": "SELECT * FROM tabulka WHERE podminka = 'hodnota';",
                "insert": "INSERT INTO tabulka (sloupec1, sloupec2) VALUES ('hodnota1', 'hodnota2');",
                "update": "UPDATE tabulka SET sloupec = 'nova hodnota' WHERE id = 1;",
                "delete": "DELETE FROM tabulka WHERE id = 1;",
                "join": "SELECT a.sloupec, b.sloupec\nFROM tabulka_a a\nINNER JOIN tabulka_b b ON a.id = b.tabulka_a_id;",
                "create": "CREATE TABLE IF NOT EXISTS tabulka (\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\n    jmeno TEXT NOT NULL,\n    email TEXT UNIQUE NOT NULL,\n    vytvoreno DATETIME DEFAULT CURRENT_TIMESTAMP\n);"
            },
            "gdscript": {
                "auto": "extends VehicleBody3D\n\n@export var engine_force := 500.0\n@export var brake_force := 1000.0\n@export var max_speed := 200.0\n@export var steering := 0.5\n\nfunc _physics_process(delta):\n    var input_vector = Vector2()\n    if Input.is_action_pressed(\"ui_right\"):\n        input_vector.x += 1\n    if Input.is_action_pressed(\"ui_left\"):\n        input_vector.x -= 1\n    if Input.is_action_pressed(\"ui_up\"):\n        input_vector.y -= 1\n    if Input.is_action_pressed(\"ui_down\"):\n        input_vector.y += 1\n    \n    input_vector = input_vector.normalized()\n    \n    var current_speed = velocity.length()\n    \n    if input_vector.y != 0:\n        engine_force = 500.0 * -input_vector.y\n    else:\n        engine_force = 0.0\n    \n    brake = 0.0\n    if input_vector.y == 0:\n        brake = brake_force * 0.5\n    \n    steering = input_vector.x * 0.5\n    \n    move_and_slide()",
                "auto2d": "extends VehicleBody2D\n\n@export var speed := 500.0\n@export var max_speed := 300.0\n@export var friction := 500.0\n@export var steer_speed := 3.0\n@export var brake_strength := 1000.0\n\nfunc _physics_process(delta):\n    var input_dir = Vector2()\n    if Input.is_action_pressed(\"ui_right\"):\n        input_dir.x += 1\n    if Input.is_action_pressed(\"ui_left\"):\n        input_dir.x -= 1\n    if Input.is_action_pressed(\"ui_up\"):\n        input_dir.y -= 1\n    if Input.is_action_pressed(\"ui_down\"):\n        input_dir.y += 1\n    \n    input_dir = input_dir.normalized()\n    \n    if input_dir != Vector2.ZERO:\n        engine_force = speed * -input_dir.y\n    else:\n        engine_force = 0.0\n        brake = friction\n    \n    if input_dir.x != 0:\n        steering = input_dir.x * steer_speed\n    else:\n        steering = 0.0\n    \n    move_and_slide()",
                "simple_car": "extends CharacterBody2D\n\n@export var speed := 300.0\n@export var acceleration := 1000.0\n@export var deceleration := 1500.0\n@export var turn_speed := 5.0\n\nfunc _physics_process(delta):\n    var input_dir = Input.get_vector(\"ui_left\", \"ui_right\", \"ui_up\", \"ui_down\")\n    \n    if input_dir:\n        velocity = velocity.move_toward(input_dir * speed, acceleration * delta)\n        rotation = input_dir.angle()\n    else:\n        velocity = velocity.move_toward(Vector2.ZERO, deceleration * delta)\n    \n    move_and_slide()",
                "vehicle3d": "extends VehicleBody3D\n\n@export var engine_force := 800.0\n@export var brake_force := 1500.0\n@export var max_speed := 250.0\n@export var steering := 0.8\n@export var mass := 1500.0\n\nfunc _ready():\n    mass = mass\n\nfunc _physics_process(delta):\n    var input_vector = Vector2()\n    if Input.is_action_pressed(\"accelerate\"):\n        input_vector.y -= 1\n    if Input.is_action_pressed(\"brake\"):\n        input_vector.y += 1\n    if Input.is_action_pressed(\"steer_right\"):\n        input_vector.x += 1\n    if Input.is_action_pressed(\"steer_left\"):\n        input_vector.x -= 1\n    \n    input_vector = input_vector.normalized()\n    \n    engine_force = 800.0 * -input_vector.y\n    brake = 0.0\n    \n    if input_vector.y == 0:\n        brake = 400.0\n    \n    steering = input_vector.x * 0.8\n    \n    if velocity.length() > max_speed:\n        engine_force = 0.0\n    \n    move_and_slide()"
            }
        }

        command_lower = command.lower()
        
        # Detekce jazyka a ukolu
        detected_lang = None
        detected_task = None
        
        for lang in code_examples.keys():
            if lang in command_lower:
                detected_lang = lang
                break
        
        if not detected_lang:
            # Snaha odhadnout jazyk
            if any(w in command_lower for w in ["python", "py"]):
                detected_lang = "python"
            elif any(w in command_lower for w in ["javascript", "js", "node"]):
                detected_lang = "javascript"
            elif any(w in command_lower for w in ["html", "web"]):
                detected_lang = "html"
            elif any(w in command_lower for w in ["css", "styl"]):
                detected_lang = "css"
            elif any(w in command_lower for w in ["sql", "databaze"]):
                detected_lang = "sql"
            elif any(w in command_lower for w in ["gdscript", "godot", "auto", "jezdi"]):
                detected_lang = "gdscript"
        
        if not detected_lang:
            self.speak("Jakej jazyk? Python, JavaScript, HTML, CSS, SQL, nebo GDScript (Godot)?")
            return
        
        # Detekce ukolu
        for task in code_examples[detected_lang].keys():
            if task in command_lower or any(w in command_lower for w in [task]):
                detected_task = task
                break
        
        if not detected_task:
            # Snaha odhadnout ukol
            if any(w in command_lower for w in ["funkce", "funkci", "metodu"]):
                detected_task = "funkce"
            elif any(w in command_lower for w in ["cyklus", "loop"]):
                detected_task = "cyklus"
            elif any(w in command_lower for w in ["podminka", "if"]):
                detected_task = "podminka"
            elif any(w in command_lower for w in ["trida", "class"]):
                detected_task = "trida"
            elif any(w in command_lower for w in ["hello", "ahoj", "uvitani"]):
                detected_task = "hello"
            elif any(w in command_lower for w in ["input", "vstup", "zadat"]):
                detected_task = "input"
            elif any(w in command_lower for w in ["soubor", "file"]):
                detected_task = "soubor"
            elif any(w in command_lower for w in ["api", "request"]):
                detected_task = "api"
            elif any(w in command_lower for w in ["formular", "form"]):
                detected_task = "formular"
            elif any(w in command_lower for w in ["tabulka", "table"]):
                detected_task = "tabulka"
            elif any(w in command_lower for w in ["seznam", "list", "ul"]):
                detected_task = "seznam"
            elif any(w in command_lower for w in ["flexbox", "flex"]):
                detected_task = "flexbox"
            elif any(w in command_lower for w in ["grid", "mrizka"]):
                detected_task = "grid"
            elif any(w in command_lower for w in ["animace", "animation"]):
                detected_task = "animace"
            elif any(w in command_lower for w in ["select", "dotaz"]):
                detected_task = "select"
            elif any(w in command_lower for w in ["insert", "vlozit"]):
                detected_task = "insert"
            elif any(w in command_lower for w in ["update", "aktualizovat"]):
                detected_task = "update"
            elif any(w in command_lower for w in ["delete", "smazat"]):
                detected_task = "delete"
            elif any(w in command_lower for w in ["join", "spojit"]):
                detected_task = "join"
            elif any(w in command_lower for w in ["create", "vytvorit", "tabulku"]):
                detected_task = "create"
            elif any(w in command_lower for w in ["auto", "jezdi", "jezdit", "car", "vehicle"]):
                if detected_lang == "gdscript":
                    detected_task = "auto"
        
        if detected_task and detected_task in code_examples.get(detected_lang, {}):
            kod = code_examples[detected_lang][detected_task]
            
            # Zkopiruj do schranky
            try:
                pyperclip.copy(kod)
                self.speak(f"Kod pro {detected_lang} - {detected_task} je pripraveny ve schrance. Vloz ho Ctrl+V.")
                print(f"\nKOD ({detected_lang} - {detected_task}):\n{kod}\n", flush=True)
            except:
                self.speak(f"Kod pro {detected_lang} - {detected_task}:")
                print(f"\nKOD ({detected_lang} - {detected_task}):\n{kod}\n", flush=True)
        else:
            # Zobraz co umi
            tasks = list(code_examples.get(detected_lang, {}).keys())
            self.speak(f"Pro {detected_lang} umim: {', '.join(tasks[:8])}. Rec mi co chces napsat.")

    def edit_code(self, command):
        import pyperclip
        
        # Priklady uprav kodu
        edits = {
            "pridej": {
                "popis": "Prida novy radek nebo blok kodu",
                "akce": "Pridej na konec souboru"
            },
            "nahrad": {
                "popis": "Nahrad cast kodu novou",
                "akce": "Nahrad text v souboru"
            },
            "prejmenuj": {
                "popis": "Prejmenuje promennou nebo funkci",
                "akce": "Prejmenuj v celym souboru"
            },
            "smaz": {
                "popis": "Smaze radek nebo blok",
                "akce": "Smaz radky"
            },
            "oprav": {
                "popis": "Opravi chybu v kodu",
                "akce": "Najdi a oprav chybu"
            },
            "najdi": {
                "popis": "Najde cast kodu",
                "akce": "Najdi v souboru"
            },
            "zabal": {
                "popis": "Zabali blok kodu",
                "akce": "Pridej zavorky"
            },
            "rozbal": {
                "popis": "Rozbali blok kodu",
                "akce": "Odeber zavorky"
            }
        }
        
        command_lower = command.lower()
        
        # Detekce operace
        operation = None
        for op in edits.keys():
            if op in command_lower:
                operation = op
                break
        
        if not operation:
            self.speak("Jaka operace? Pridej, nahrad, prejmenuj, smaz, oprav, najdi, zabal nebo rozbal.")
            return
        
        # Vytvor sablonu pro upravu
        sablona = f"""# UPRAVA KODU - {operation.upper()}
# {edits[operation]['popis']}
#
# Napis mi:
# 1. Cesta k souboru
# 2. Co presne chces udelat
# 3. Priklad: {edits[operation]['akce']}
#
# PRIKLAD:
# soubor: C:\\Users\\nazev\\kod.py
# operace: {operation}
# co: text ktery chces zmenit
# na: novy text
#
# Nebo mi rekni co chces udelat a ja ti pomuzu!"""
        
        try:
            pyperclip.copy(sablona)
            self.speak(f"Sablona pro {operation} je pripravena ve schrance. Vloz ji a napis co chces udelat!")
            print(f"\nSABLONA PRO UPRAVU:\n{sablona}\n", flush=True)
        except:
            self.speak(f"Pro {operation} mi rekni: cesta k souboru, co chces zmenit, a na co.")
            print(f"\nSABLONA:\n{sablona}\n", flush=True)

    def find_in_code(self, command):
        import pyperclip
        
        # Vytvor skript pro hledani v souborech
        skript = '''# HLEDANI V KODU
# 
# Jak pouzivat:
# 1. Otevri slozku s projektem
# 2. Spust tento skript
# 3. Zadej co hledas
#
# Priklad:
# hledam: "def funkce"
# soubory: "*.py"
#
# NEBO mi rekni co hledas a ja to najdu!'''
        
        try:
            pyperclip.copy(skript)
            self.speak("Skript pro hledani je pripraveny ve schrance!")
            print(f"\nSKRIPT PRO HLEDANI:\n{skript}\n", flush=True)
        except:
            self.speak("Rec mi co hledas a v jakem souboru.")

    def analyze_code(self, command):
        # Analyza kodu - co dela
        sablona = """# ANALYZA KODU
# 
# Vloz kod a ja ti reknu:
# - Co dela
# - Jak funguje
# - Jak ho vylepsit
# - Kde muze byt chyba
#
# Priklad:
# Vloz sem svuj kod a ja ho analyzuju!
# Nebo mi rekni cestu k souboru.
#
# CO UMIM:
# - Vysvetlit co dela kazdy radek
# - Najit chyby
# - Navrhnout vylepseni
# - Optimalizovat kod
# - Pridat komentare"""
        
        try:
            pyperclip.copy(sablona)
            self.speak("Sablona pro analyzu je pripravena ve schrance!")
            print(f"\nSABLONA PRO ANALYZU:\n{sablona}\n", flush=True)
        except:
            self.speak("Vloz kod nebo mi rekni cestu k souboru a ja ho analyzuju.")

    def suggest_improvements(self, command):
        import pyperclip
        
        # Typy vylepseni
        suggestions = {
            "funkce": [
                "Pridej docstring ke kazde funkci",
                "Pridej type hints",
                "Rozdel velke funkce na mensi",
                "Pridej error handling",
                "Oprav命名 convention"
            ],
            "tridy": [
                "Pridej docstring ke tride",
                "Pridej __init__ metodu",
                "Rozdel tridy na mensi",
                "Pridej property dekoratory",
                "Pridej __str__ a __repr__"
            ],
            "kod": [
                "Oduplikuj kod",
                "Pridej komentare",
                "Optimalizuj podminky",
                "Pridej logging",
                "Oprav chyby"
            ],
            "testy": [
                "Pridej unit testy",
                "Pridej integration testy",
                "Otestuj edge cases",
                "Pridej mocky",
                "Zlepsi coverage"
            ],
            "bepecnost": [
                "Oprav SQL injection",
                "Pridej validaci vstupu",
                "Sifruj hesla",
                "Pridej CSRF ochranu",
                "Kontroluj opravneni"
            ],
            "vykon": [
                "Optimalizuj databazove dotazy",
                "Pridej cachovani",
                "Oprav memory leaky",
                "Pridej async/await",
                "Optimalizuj cykly"
            ]
        }
        
        command_lower = command.lower()
        
        # Detekce typu vylepseni
        typ = None
        for t in suggestions.keys():
            if t in command_lower:
                typ = t
                break
        
        if not typ:
            # Nabidni vsechny typy
            self.speak("Jaky typ vylepseni? Funkce, tridy, kod, testy, bezpecnost nebo vykon?")
            return
        
        # Vytvor seznam tipu
        tipy = suggestions[typ]
        tip_text = f"Tipy pro {typ}:\n"
        for i, tip in enumerate(tipy, 1):
            tip_text += f"{i}. {tip}\n"
        
        tip_text += "\nNapis mi který tip chces aplikovat a ja ti pomuzu!"
        
        try:
            pyperclip.copy(tip_text)
            self.speak(f"Tipy pro {typ} jsou pripraveny ve schrance!")
            print(f"\nTIPY PRO {typ.upper()}:\n{tip_text}\n", flush=True)
        except:
            self.speak(f"Tipy pro {typ}: {', '.join(tipy)}")
            print(f"\nTIPY:\n{tip_text}\n", flush=True)

    def analyze_vscode(self):
        import pygetwindow as gw
        import pyperclip
        import time
        
        # Najdi VS Code
        windows = [w for w in gw.getAllWindows() if 'visual studio code' in w.title.lower() or 'vscode' in w.title.lower()]
        
        if not windows:
            self.speak("Visual Studio Code neni otevreny.")
            return
        
        win = windows[0]
        try:
            if win.isMinimized:
                win.restore()
            win.activate()
            time.sleep(0.5)
            
            # Zkopiruj obsah (Ctrl+A, Ctrl+C)
            import pyautogui
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.2)
            pyautogui.hotkey('ctrl', 'c')
            time.sleep(0.3)
            
            # Ziskej ze schranky
            obsah = pyperclip.paste()
            
            if obsah:
                self.speak(f"Nacten kod z VS Code ({len(obsah)} znaku). Analyzuju!")
                
                # Zakladni analyza
                radky = obsah.split("\n")
                pocet_radku = len(radky)
                pocet_funkci = sum(1 for r in radky if "def " in r)
                pocet_trid = sum(1 for r in radky if "class " in r)
                pocet_komentaru = sum(1 for r in radky if r.strip().startswith("#") or r.strip().startswith("//"))
                
                analyza = f"""Analyza VS Code kodu:
- Radku: {pocet_radku}
- Funkci: {pocet_funkci}
- Trid: {pocet_trid}
- Komentaru: {pocet_komentaru}

Tipy co pridat:
"""
                if pocet_funkci == 0:
                    analyza += "- Pridej funkce pro strukturu kodu\n"
                if pocet_trid == 0:
                    analyza += "- Pridej tridy pro OOP\n"
                if pocet_komentaru < pocet_radku // 10:
                    analyza += "- Pridej vic komentaru\n"
                if "try" not in obsah:
                    analyza += "- Pridej error handling (try/except)\n"
                if "def __init__" in obsah and "__str__" not in obsah:
                    analyza += "- Pridej __str__ metodu\n"
                if "import" in obsah and "test" not in obsah:
                    analyza += "- Pridej testy\n"
                
                print(f"\n{analyza}\n", flush=True)
                self.speak("Analyza hotova! Podivej se na tipy.")
            else:
                self.speak("Nepodarilo se ziskat kod z VS Code.")
                
        except Exception as e:
            self.speak(f"Chyba pri praci s VS Code: {e}")

    def suggest_code(self):
        import pyperclip
        import pygetwindow as gw
        import time
        
        # Najdi VS Code
        windows = [w for w in gw.getAllWindows() if 'visual studio code' in w.title.lower() or 'vscode' in w.title.lower()]
        
        if not windows:
            self.speak("Visual Studio Code neni otevreny.")
            return
        
        win = windows[0]
        try:
            if win.isMinimized:
                win.restore()
            win.activate()
            time.sleep(0.5)
            
            # Zkopiruj obsah
            import pyautogui
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.2)
            pyautogui.hotkey('ctrl', 'c')
            time.sleep(0.3)
            
            obsah = pyperclip.paste()
            
            if obsah:
                # Detekce jazyka
                jazyk = "python"
                if "function" in obsah or "const " in obsah or "let " in obsah:
                    jazyk = "javascript"
                elif "<html" in obsah or "<div" in obsah:
                    jazyk = "html"
                elif "{" in obsah and "}" in obsah and ";" in obsah:
                    jazyk = "css"
                
                # Nabidni tipy podle jazyka
                tipy = {
                    "python": [
                        "Pridej if __name__ == '__main__':",
                        "Pridej logging misto print",
                        "Pridej type hints",
                        "Pridej docstringy",
                        "Pridej try/except",
                        "Pridej dataclass misto dict",
                        "Pridej list comprehension",
                        "Pridej generator misto listu"
                    ],
                    "javascript": [
                        "Pridej async/await",
                        "Pridej try/catch",
                        "Pridej JSDoc komentare",
                        "Pridej optional chaining (?.)",
                        "Pridej nullish coalescing (??)",
                        "Pridej destructuring",
                        "Pridej template literals",
                        "Pridej arrow functions"
                    ],
                    "html": [
                        "Pridej meta tagy",
                        "Pridej ARIA atributy",
                        "Pridej semantické tagy",
                        "Pridej favicon",
                        "Pridej Open Graph tagy",
                        "Pridej responsive meta"
                    ],
                    "css": [
                        "Pridej CSS proměnné",
                        "Pridej media queries",
                        "Pridej animace",
                        "Pridej dark mode",
                        "Pridej flexbox/grid",
                        "Pridej hover efekty"
                    ]
                }
                
                # Vytvor tipy
                tip_text = f"Tipy pro {jazyk}:\n"
                for i, tip in enumerate(tipy.get(jazyk, tipy["python"]), 1):
                    tip_text += f"{i}. {tip}\n"
                
                tip_text += "\nNapis mi který tip chces a ja ti pomuzu!"
                
                try:
                    pyperclip.copy(tip_text)
                    self.speak(f"Tipy pro {jazyk} jsou pripraveny ve schrance!")
                    print(f"\nTIPY PRO {jazyk.upper()}:\n{tip_text}\n", flush=True)
                except:
                    self.speak(f"Tipy pro {jazyk}: {', '.join(tipy.get(jazyk, tipy['python'])[:5])}")
                    print(f"\nTIPY:\n{tip_text}\n", flush=True)
            else:
                self.speak("Nepodarilo se ziskat kod z VS Code.")
                
        except Exception as e:
            self.speak(f"Chyba pri praci s VS Code: {e}")

    def write_to_file(self, command):
        import pyperclip
        
        # Priklady prikazu pro zapis do souboru
        examples = [
            "zapis do souboru: cesta/k/souboru.py",
            "pridej do souboru: cesta/k/souboru.py",
            "nahrad v souboru: cesta/k/souboru.py",
            "oprav v souboru: cesta/k/souboru.py",
            "smaz ze souboru: cesta/k/souboru.py"
        ]
        
        command_lower = command.lower()
        
        # Detekce cesty k souboru
        soubor = None
        for cast in command.split():
            if "." in cast and ("/" in cast or "\\" in cast):
                soubor = cast
                break
        
        if not soubor:
            # Vytvor sablonu
            sablona = """# ZAPIS DO KODU
# 
# Jak pouzivat:
# 1. Rec mi: "zapis do souboru: cesta/k/souboru.py"
# 2. Ja otevru soubor
# 3. Rec mi co chces pridat/zmenit
# 4. Ja to zapisu
#
# PRIKLADY:
# zapis do souboru: C:\\Projekt\\main.py
# pridej funkci: def hello(): print("ahoj")
# nahrad: stare -> nove
# smaz: radek 10-15
#
# NEBO mi rekni co chces udelat!"""
            
            try:
                pyperclip.copy(sablona)
                self.speak("Sablona pro zapis je pripravena ve schrance!")
                print(f"\nSABLONA PRO ZAPIS:\n{sablona}\n", flush=True)
            except:
                self.speak("Rec mi cestu k souboru a co chces zapsat.")
            return
        
        # Pokud mam soubor, nacti ho
        if os.path.exists(soubor):
            try:
                with open(soubor, 'r', encoding='utf-8') as f:
                    obsah = f.read()
                
                self.speak(f"Nacten soubor {soubor}. Co chces zmenit?")
                print(f"\nSOUBOR: {soubor}\n", flush=True)
                print(f"OBSAH ({len(obsah)} znaku):\n{obsah[:500]}...\n", flush=True)
                
                # Uloz kontext pro pozdejsi upravu
                self.chat_context["last_file"] = soubor
                self.chat_context["last_file_content"] = obsah
                
            except Exception as e:
                self.speak(f"Nepodarilo se nacist soubor: {e}")
        else:
            self.speak(f"Soubor {soubor} neexistuje. Chces ho vytvorit?")
            self.chat_context["last_file"] = soubor
            self.chat_context["last_file_content"] = ""

    def edit_file(self, command):
        import pyperclip
        
        # Kontrola jestli mam kontext souboru
        if "last_file" not in self.chat_context or not self.chat_context["last_file"]:
            self.speak("Nejdriv mi rekni cestu k souboru.")
            return
        
        soubor = self.chat_context["last_file"]
        stary_obsah = self.chat_context.get("last_file_content", "")
        
        command_lower = command.lower()
        
        # Detekce operace
        if any(w in command_lower for w in ["pridej", "pridat", "nove"]):
            # Prida text na konec
            novy_text = command
            for word in ["pridej", "pridat", "nove", "na konec"]:
                novy_text = novy_text.replace(word, "")
            novy_text = novy_text.strip()
            
            if novy_text:
                novy_obsah = stary_obsah + "\n" + novy_text
                try:
                    with open(soubor, 'w', encoding='utf-8') as f:
                        f.write(novy_obsah)
                    self.speak(f"Pridano do {soubor}!")
                    self.chat_context["last_file_content"] = novy_obsah
                except Exception as e:
                    self.speak(f"Chyba pri zapisu: {e}")
            else:
                self.speak("Co mam pridat?")
        
        elif any(w in command_lower for w in ["nahrad", "zmenit", "zmen"]):
            # Nahradeni textu
            if "->" in command:
                parts = command.split("->")
                stare = parts[0].replace("nahrad", "").replace("zmenit", "").replace("zmen", "").strip()
                nove = parts[1].strip()
                
                if stare and nove:
                    novy_obsah = stary_obsah.replace(stare, nove)
                    try:
                        with open(soubor, 'w', encoding='utf-8') as f:
                            f.write(novy_obsah)
                        self.speak(f"Nahrazeno v {soubor}!")
                        self.chat_context["last_file_content"] = novy_obsah
                    except Exception as e:
                        self.speak(f"Chyba pri zapisu: {e}")
                else:
                    self.speak("Format: nahrad [stare] -> [nove]")
            else:
                self.speak("Format: nahrad [stare] -> [nove]")
        
        elif any(w in command_lower for w in ["smaz", "smazat"]):
            # Smazani textu
            smazat = command.replace("smaz", "").replace("smazat", "").strip()
            if smazat:
                novy_obsah = stary_obsah.replace(smazat, "")
                try:
                    with open(soubor, 'w', encoding='utf-8') as f:
                        f.write(novy_obsah)
                    self.speak(f"Smazano z {soubor}!")
                    self.chat_context["last_file_content"] = novy_obsah
                except Exception as e:
                    self.speak(f"Chyba pri zapisu: {e}")
            else:
                self.speak("Co mam smazat?")
        
        elif any(w in command_lower for w in ["najdi", "najit"]):
            # Hledani v souboru
            hledat = command.replace("najdi", "").replace("najit", "").strip()
            if hledat:
                radky = stary_obsah.split("\n")
                nalezy = []
                for i, radek in enumerate(radky, 1):
                    if hledat.lower() in radek.lower():
                        nalezy.append(f"Radek {i}: {radek.strip()}")
                
                if nalezy:
                    self.speak(f"Nalezeno {len(nalezy)} vysledku!")
                    print(f"\nNALEZY:\n" + "\n".join(nalezy[:10]) + "\n", flush=True)
                else:
                    self.speak(f"Nic jsem nenasel v {soubor}.")
            else:
                self.speak("Co mam hledat?")
        
        else:
            self.speak("Co chces udelat? Pridej, nahrad, smaz nebo najdi.")

    _CZ_IRREGULAR = {
        "psech": "pes", "psechu": "pes", "psem": "pes", "psovi": "pes", "psa": "pes",
        "psi": "pes", "psy": "pes", "psu": "pes", "psům": "pes", "psech": "pes",
        "kocek": "kočka", "kockach": "kočka", "kočkách": "kočka", "kocky": "kočka",
        "kočky": "kočka", "kocku": "kočka", "kočku": "kočka",
        "aut": "auto", "autum": "auto", "autům": "auto", "autech": "auto", "auty": "auto",
        "mest": "město", "měst": "město", "mestech": "město", "městech": "město",
        "zen": "žena", "žen": "žena", "zenach": "žena", "ženách": "žena",
        "muzu": "muž", "mužů": "muž", "muzich": "muž", "mužích": "muž",
        "deti": "dítě", "dětí": "dítě", "detem": "dítě",
        "stromu": "strom", "stromů": "strom", "stromech": "strom",
        "kvetin": "květina", "květin": "květina", "kvetinach": "květina",
    }

    def _singular_variants(self, topic):
        import re
        words = re.findall(r"[a-záčďéěíňóřšťúůýž]+", topic.lower())
        stop = {"vytvor", "vytvoř", "vytvorit", "vytvořit", "udelej", "udělej", "udelat",
                "udělat", "prezentaci", "prezentace", "prezentku", "powerpoint", "powerpointu",
                "pptx", "slidy", "snimky", "snímky", "prosim", "prosím", "mi", "v", "o", "na",
                "s", "z", "za", "pro", "k", "ke", "a", "i", "obrazky", "obrázky", "obrazkem",
                "obrázkem", "obrazků", "fotky", "fotkami", "najdi", "najít", "dej", "pridej"}
        words = [w for w in words if w not in stop]
        if not words:
            return []
        base = " ".join(words)
        variants = [base]
        per_word = []
        for w in words:
            opts = [w]
            if w in self._CZ_IRREGULAR:
                opts.append(self._CZ_IRREGULAR[w])
            else:
                if w.endswith("ách") and len(w) > 4:
                    opts += [w[:-3] + "a", w[:-3]]
                elif w.endswith("ech") and len(w) > 4:
                    opts += [w[:-3] + "o", w[:-3] + "a", w[:-3]]
                elif w.endswith("ích") and len(w) > 4:
                    opts += [w[:-3] + "e", w[:-3]]
                elif w.endswith("ům") and len(w) > 3:
                    opts.append(w[:-2])
                elif w.endswith("ů") and len(w) > 3:
                    opts.append(w[:-1])
                elif w.endswith("ami") and len(w) > 4:
                    opts.append(w[:-3] + "a")
                elif w.endswith("emi") and len(w) > 4:
                    opts.append(w[:-3] + "e")
            seen = []
            for o in opts:
                if o not in seen:
                    seen.append(o)
            per_word.append(seen[:3])
        import itertools
        for combo in itertools.product(*per_word):
            v = " ".join(combo)
            if v != base and v not in variants:
                variants.append(v)
            if len(variants) >= 4:
                break
        return variants

    def _extract_presentation_topic(self, command):
        import re
        topic = re.sub(r"https?://\S+", " ", command.lower())
        variants = self._singular_variants(topic)
        # Vrat puvodni (nesklonne) zneni pro nazev; hledani resi varianty
        stop = {"vytvor", "vytvoř", "vytvorit", "vytvořit", "udelej", "udělej", "udelat",
                "udělat", "prezentaci", "prezentace", "prezentku", "powerpoint", "powerpointu",
                "pptx", "slidy", "snimky", "snímky", "prosim", "prosím", "mi", "v", "o", "na",
                "s", "z", "za", "pro", "k", "ke", "a", "i", "obrazky", "obrázky", "obrazkem",
                "obrázkem", "obrazků", "fotky", "fotkami", "najdi", "najít", "dej", "pridej"}
        words = [w for w in re.findall(r"[a-záčďéěíňóřšťúůýž]+", topic) if w not in stop]
        raw = " ".join(words).strip()
        return raw if raw else "Moje prezentace"

    def _collect_presentation_images(self, command):
        import re
        import os
        import tempfile
        found = []
        urls = re.findall(r"https?://\S+\.(?:jpg|jpeg|png|gif|webp|bmp)(?:\?\S*)?", command, flags=re.IGNORECASE)
        # I lokalni cesty v uvozovkach nebo existujici soubory
        quoted = re.findall(r'"([^"]+\.(?:jpg|jpeg|png|gif|webp|bmp))"', command, flags=re.IGNORECASE)
        candidates = list(urls)
        for q in quoted:
            if os.path.exists(q):
                candidates.append(q)
        tmp_files = []
        for u in candidates[:4]:
            if u.lower().startswith("http"):
                try:
                    import requests
                    r = requests.get(u, timeout=15, headers={"User-Agent": "Mozilla/5.0"})
                    ctype = r.headers.get("Content-Type", "")
                    if r.status_code == 200 and (ctype.startswith("image/") or len(r.content) > 1000):
                        ext = ".jpg"
                        for e in [".png", ".gif", ".webp", ".bmp", ".jpeg", ".jpg"]:
                            if e in u.lower():
                                ext = e
                                break
                        fd, path = tempfile.mkstemp(suffix=ext)
                        os.close(fd)
                        with open(path, "wb") as f:
                            f.write(r.content)
                        tmp_files.append(path)
                        found.append(path)
                    else:
                        print(f"Obrazek nelze stahnout (HTTP {r.status_code}): {u}", flush=True)
                except Exception as e:
                    print(f"Obrazek nelze stahnout: {u} ({e})", flush=True)
            elif os.path.exists(u):
                found.append(u)
        return found, tmp_files

    def _fetch_topic_summary(self, topic):
        import urllib.parse
        import difflib
        try:
            import requests
            h = {"User-Agent": "JARVIS/1.0 (osobni asistent)"}
            variants = [topic] + [v for v in self._singular_variants(topic) if v != topic]
            best = None
            best_score = -1.0
            for variant in variants[:4]:
                try:
                    s = requests.get("https://cs.wikipedia.org/w/api.php",
                                     params={"action": "query", "list": "search",
                                             "srsearch": variant, "format": "json", "srlimit": 3},
                                     timeout=15, headers=h).json()
                except Exception:
                    continue
                for hit in s.get("query", {}).get("search", []):
                    title = hit.get("title", "")
                    try:
                        r = requests.get(
                            f"https://cs.wikipedia.org/api/rest_v1/page/summary/{urllib.parse.quote(title)}",
                            timeout=15, headers=h).json()
                    except Exception:
                        continue
                    if r.get("type") == "disambiguation":
                        continue
                    extract = (r.get("extract") or "").strip()
                    if len(extract) < 150:
                        continue
                    tl, vl = title.lower(), variant.lower()
                    if tl == vl or tl.startswith(vl) or vl in tl:
                        match = 1.0
                    else:
                        match = difflib.SequenceMatcher(None, tl, vl).ratio()
                    score = 2.0 * match + min(len(extract), 1500) / 1500.0
                    if score > best_score:
                        best_score = score
                        en_title = ""
                        try:
                            ll = requests.get("https://cs.wikipedia.org/w/api.php", params={
                                "action": "query", "titles": title, "prop": "langlinks",
                                "lllang": "en", "format": "json"}, timeout=15, headers=h).json()
                            pages = (ll.get("query") or {}).get("pages", {}).values()
                            for pg in pages:
                                lls = pg.get("langlinks") or []
                                if lls:
                                    en_title = lls[0].get("*", "")
                        except Exception:
                            pass
                        best = {"title": r.get("title") or title, "extract": extract,
                                "url": (r.get("content_urls") or {}).get("desktop", {}).get("page", ""),
                                "en_title": en_title, "score": round(score, 2)}
            if best and best_score >= 0.8:
                return best
            if best:
                print(f"Wikipedia: nejlepsi shoda slaba ({best['title']}, score={best_score}), preskakuji.", flush=True)
            return None
        except Exception as e:
            print(f"Wikipedia nenalezena: {e}", flush=True)
            return None

    def _search_commons_images(self, query, limit=3):
        import time
        for attempt in (1, 2):
            try:
                import requests
                h = {"User-Agent": "JARVIS/1.0 (osobni asistent)"}
                r = requests.get("https://commons.wikimedia.org/w/api.php", params={
                    "action": "query", "format": "json", "generator": "search",
                    "gsrsearch": f"{query} filetype:bitmap", "gsrnamespace": 6,
                    "gsrlimit": 10, "prop": "imageinfo",
                    "iiprop": "url|extmetadata", "iiurlwidth": 1000,
                }, timeout=15, headers=h)
                r.raise_for_status()
                r = r.json()
                pages = (r.get("query") or {}).get("pages", {}).values()
                out = []
                for p in pages:
                    info = (p.get("imageinfo") or [{}])[0]
                    thumb = info.get("thumburl") or info.get("url")
                    if not thumb:
                        continue
                    meta = info.get("extmetadata") or {}
                    artist = (meta.get("Artist") or {}).get("value", "")
                    import re
                    artist = re.sub(r"<[^>]+>", "", artist).strip()[:80]
                    lic = (meta.get("LicenseShortName") or {}).get("value", "")
                    out.append({"thumb": thumb, "author": artist or "neuveden",
                                "lic": lic or "volna licence",
                                "page": info.get("descriptionurl", "")})
                    if len(out) >= limit:
                        break
                return out
            except Exception as e:
                print(f"Commons pokus {attempt} selhal: {e}", flush=True)
                if "429" in str(e):
                    time.sleep(10)
                else:
                    time.sleep(2)
        return []

    def _to_bullets(self, text, count=4, max_len=130):
        import re as _re
        sents = [s.strip() for s in _re.split(r"(?<=[.!?])\s+", text) if len(s.strip()) > 25]
        out = []
        for s in sents[:count]:
            if len(s) > max_len:
                cut = s[:max_len].rsplit(" ", 1)[0]
                s = cut + "…"
            out.append(s)
        return out

    def create_presentation(self, command):
        import re
        import datetime
        topic = self._extract_presentation_topic(command)
        safe = re.sub(r"[^a-zA-Z0-9áčďéěíňóřšťúůýžÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ_-]+", "_", topic).strip("_") or "prezentace"
        base_dir = os.path.dirname(os.path.abspath(__file__))
        pptx_path = os.path.join(base_dir, f"prezentace_{safe[:40]}.pptx")

        wiki = None
        if topic.lower() != "moje prezentace":
            self.speak(f"Hledam informace o {topic} na Wikipedii.")
            wiki = self._fetch_topic_summary(topic)

        today = datetime.date.today()
        date_str = f"{today.day}. {today.month}. {today.year}"
        if wiki:
            import re as _re
            parts = _re.split(r"(?<=[.!?])\s+", wiki["extract"])
            parts = [p.strip() for p in parts if len(p.strip()) > 25]
            title = wiki["title"]
            slides = [
                (title, [f"Prezentace • {date_str}", "Zdroj: Wikipedie"]),
                ("Osnova", ["1. Úvod", "2. Hlavní část", "3. Zajímavosti", "4. Kvíz", "5. Závěr a zdroje"]),
                ("Úvod", self._to_bullets(" ".join(parts[0:2]), 3) or [wiki["extract"][:130]]),
                ("Hlavní část", self._to_bullets(" ".join(parts[2:6]), 4) or [wiki["extract"][:130]]),
            ]
            rest = " ".join(parts[6:9])
            if rest.strip():
                slides.append(("Zajímavosti", self._to_bullets(rest, 3)))
            slides.append(("Kvíz", [
                f"Co tě na tématu {title} zaujalo nejvíc?",
                "Kde se s ním setkáváš v běžném životě?",
                "Co bys o něm řekl kamarádovi ve třech větách?",
            ]))
            first = (parts[0][:110].rsplit(" ", 1)[0] + "…") if parts and len(parts[0]) > 110 else (parts[0] if parts else title)
            slides.append(("Závěr", [f"Nejdůležitější: {first}", f"Téma: {title}", "Děkuji za pozornost!"]))
            zdroj_url = wiki.get("url") or "https://cs.wikipedia.org"
        else:
            slides = [
                (topic, [f"Prezentace • {date_str}"]),
                ("Osnova", ["1. Úvod", "2. Hlavní část", "3. Kvíz", "4. Závěr"]),
                ("Úvod", [f"Co je: {topic}?", "Proč je to důležité?"]),
                ("Hlavní část", ["Základní informace", "Příklady z praxe", "Tipy"]),
                ("Kvíz", ["Co tě na tématu zaujalo nejvíc?", "Kde se s ním setkáváš v praxi?"]),
                ("Závěr", ["Co jsme se naučili", "Děkuji za pozornost!"]),
            ]
            zdroj_url = ""

        images, tmp_files = self._collect_presentation_images(command)
        img_infos = []
        if not images and topic.lower() != "moje prezentace":
            query = (wiki.get("en_title") or wiki["title"]) if wiki else topic
            self.speak(f"Hledam volne obrazky o {query}.")
            for item in self._search_commons_images(query, limit=3):
                try:
                    import requests
                    import tempfile
                    r = requests.get(item["thumb"], timeout=20, headers={"User-Agent": "Mozilla/5.0"})
                    if r.status_code == 200 and len(r.content) > 2000:
                        fd, path = tempfile.mkstemp(suffix=".jpg")
                        os.close(fd)
                        with open(path, "wb") as f:
                            f.write(r.content)
                        tmp_files.append(path)
                        images.append(path)
                        img_infos.append(item)
                except Exception as e:
                    print(f"Obrazek z Commons nelze stahnout: {e}", flush=True)
        zdroje = []
        if zdroj_url:
            zdroje.append(f"Text: {zdroj_url}")
        for it in img_infos:
            zdroje.append(f"Obrázek: {it.get('page','')} (autor: {it.get('author','neuveden')}, {it.get('lic','')})")
        if zdroje:
            slides.append(("Zdroje", zdroje))
        total = len(slides)
        try:
            from pptx import Presentation
            from pptx.util import Inches
            prs = Presentation()
            from pptx.util import Pt
            from pptx.dml.color import RGBColor
            from pptx.enum.text import MSO_AUTO_SIZE
            from pptx.enum.shapes import MSO_SHAPE
            NAVY = RGBColor(0x1F, 0x38, 0x64)
            ACCENT = RGBColor(0xED, 0x7D, 0x31)
            BODY = RGBColor(0x26, 0x26, 0x26)
            GRAY = RGBColor(0x88, 0x88, 0x88)
            WHITE = RGBColor(0xFF, 0xFF, 0xFF)
            blank_layout = prs.slide_layouts[6]
            NO_IMAGE = {"Osnova", "Zdroje", "Kvíz"}

            def _bullets(slide, left, top, width, height, items, size=20, color=BODY, bold=False):
                box = slide.shapes.add_textbox(left, top, width, height)
                tf = box.text_frame
                tf.word_wrap = True
                try:
                    tf.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
                except Exception:
                    pass
                first = True
                for item in items:
                    p = tf.paragraphs[0] if first else tf.add_paragraph()
                    first = False
                    p.level = 0
                    try:
                        p.space_after = Pt(8)
                    except Exception:
                        pass
                    run = p.add_run()
                    run.text = str(item)
                    run.font.size = Pt(size)
                    run.font.bold = bold
                    run.font.color.rgb = color
                return box

            def _bar(slide, left=Inches(0.5), top=Inches(1.05), width=Inches(1.2)):
                try:
                    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, left, top, width, Pt(5))
                    shape.fill.solid()
                    shape.fill.fore_color.rgb = ACCENT
                    shape.line.fill.background()
                except Exception:
                    pass

            img_idx = 0
            img_caps = [None] * max(0, len(images) - len(img_infos)) + img_infos
            for i, (title, body) in enumerate(slides):
                items = list(body) if isinstance(body, list) else [str(body)]
                if i == 0:
                    slide = prs.slides.add_slide(blank_layout)
                    try:
                        bg = slide.background.fill
                        bg.solid()
                        bg.fore_color.rgb = NAVY
                    except Exception:
                        pass
                    _bullets(slide, Inches(0.5), Inches(1.6), Inches(9.0), Inches(2.2),
                             [title], size=44, color=WHITE, bold=True)
                    try:
                        shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.5), Inches(3.9), Inches(1.6), Pt(6))
                        shape.fill.solid()
                        shape.fill.fore_color.rgb = ACCENT
                        shape.line.fill.background()
                    except Exception:
                        pass
                    _bullets(slide, Inches(0.5), Inches(4.3), Inches(9.0), Inches(1.5),
                             items, size=20, color=WHITE)
                    _bullets(slide, Inches(0.5), Inches(6.9), Inches(9.0), Inches(0.3),
                             [f"Strana {i + 1} z {total}"], size=9, color=GRAY)
                else:
                    slide = prs.slides.add_slide(blank_layout)
                    _bullets(slide, Inches(0.5), Inches(0.2), Inches(9.0), Inches(0.85),
                             [title], size=32, color=NAVY, bold=True)
                    _bar(slide)
                    use_img = (title not in NO_IMAGE and img_idx < len(images))
                    if use_img:
                        _bullets(slide, Inches(0.5), Inches(1.4), Inches(4.8), Inches(5.2),
                                 items, size=20, color=BODY)
                        try:
                            from PIL import Image as _PIL
                            iw, ih = _PIL.open(images[img_idx]).size
                            scale = min(Inches(3.9) / iw, Inches(3.4) / ih)
                            w, h = int(iw * scale), int(ih * scale)
                            left = Inches(5.6) + (Inches(3.9) - w) // 2
                            slide.shapes.add_picture(images[img_idx], left, Inches(1.5), width=w, height=h)
                            cap = img_caps[img_idx] if img_idx < len(img_caps) else None
                            if cap:
                                _bullets(slide, Inches(5.6), Inches(1.5) + h + Inches(0.1),
                                         Inches(3.9), Inches(0.4),
                                         [f"Foto: {cap.get('author', 'neuveden')}"], size=9, color=GRAY)
                            img_idx += 1
                        except Exception as e:
                            print(f"Obrázek se nepovedlo vložit: {e}", flush=True)
                            _bullets(slide, Inches(0.5), Inches(1.4), Inches(9.0), Inches(5.2),
                                     items, size=20, color=BODY)
                    else:
                        _bullets(slide, Inches(0.5), Inches(1.4), Inches(9.0), Inches(5.2),
                                 items, size=24 if title == "Kvíz" else 20, color=BODY)
                    if title != "Zdroje":
                        _bullets(slide, Inches(0.5), Inches(7.0), Inches(9.0), Inches(0.3),
                                 [f"Strana {i + 1} z {total} • Wikipedie (CC BY-SA) • Wikimedia Commons"],
                                 size=8, color=GRAY)
            prs.save(pptx_path)
            for p in tmp_files:
                try:
                    os.remove(p)
                except Exception:
                    pass
            if images:
                self.speak(f"Prezentace o {topic} je hotova s {len(images)} volne licencovanymi obrazky a textem z Wikipedie. Ulozeno jako {os.path.basename(pptx_path)}.")
            elif wiki:
                self.speak(f"Prezentace o {topic} je hotova s textem z Wikipedie. Volne obrazky jsem nenasel, muzes doplnit vlastni odkazy.")
            else:
                self.speak(f"Prezentace o {topic} je hotova. K tematu jsem nenasel clanek ani obrazky, dopln vlastni.")
            print(f"\nPREZENTACE: {pptx_path}\n", flush=True)
            try:
                os.startfile(pptx_path)
            except Exception:
                pass
        except ImportError:
            html_path = os.path.join(base_dir, f"prezentace_{safe[:40]}.html")
            html_slides = "".join(
                f"<section style='page-break-after:always;border:1px solid #ccc;padding:40px;margin:20px;'>"
                f"<h1>{t}</h1><pre style='font-size:18px;white-space:pre-wrap;'>"
                f"{chr(10).join(b) if isinstance(b, list) else b}</pre></section>"
                for t, b in slides
            )
            html = f"<!DOCTYPE html><html lang='cs'><head><meta charset='UTF-8'><title>{topic}</title></head><body>{html_slides}</body></html>"
            try:
                with open(html_path, "w", encoding="utf-8") as f:
                    f.write(html)
                self.speak(f"Nemam knihovnu python-pptx, tak jsem vytvoril HTML verzi. Nainstaluj pip install python-pptx pro PowerPoint.")
                print(f"\nPREZENTACE HTML: {html_path}\n", flush=True)
                try:
                    webbrowser.open(html_path)
                except Exception:
                    pass
            except Exception as e:
                self.speak(f"Nepodarilo se vytvorit prezentaci: {e}")
        except Exception as e:
            self.speak(f"Nepodarilo se vytvorit prezentaci: {e}")

    def create_godot_car(self, command):
        import pyperclip
        cmd = command.lower()
        if "2d" in cmd or "2 d" in cmd:
            kod = (
                "extends VehicleBody2D\n\n"
                "@export var speed := 500.0\n"
                "@export var steer_speed := 3.0\n\n"
                "func _physics_process(delta):\n"
                "    var fwd := Input.get_axis(\"ui_down\", \"ui_up\")\n"
                "    engine_force = speed * fwd\n"
                "    steering = Input.get_axis(\"ui_left\", \"ui_right\") * steer_speed\n"
                "    if fwd == 0:\n"
                "        brake = 500.0\n"
                "    else:\n"
                "        brake = 0.0\n"
            )
            popis = "2D auto (VehicleBody2D)"
        else:
            kod = (
                "extends VehicleBody3D\n\n"
                "@export var max_speed := 200.0\n\n"
                "func _physics_process(_delta):\n"
                "    var fwd := Input.get_axis(\"ui_down\", \"ui_up\")\n"
                "    engine_force = 500.0 * fwd\n"
                "    steering = Input.get_axis(\"ui_left\", \"ui_right\") * 0.5\n"
                "    if fwd == 0:\n"
                "        brake = 500.0\n"
                "    else:\n"
                "        brake = 0.0\n"
                "    if velocity.length() > max_speed:\n"
                "        engine_force = 0.0\n"
            )
            popis = "3D auto (VehicleBody3D)"
        try:
            pyperclip.copy(kod)
            self.speak(f"Godot kod pro jezdici auto je ve schrance: {popis}. Vloz ho Ctrl+V do .gd souboru.")
            print(f"\nGODOT AUTO ({popis}):\n{kod}\n", flush=True)
        except Exception:
            self.speak(f"Godot kod pro auto: {popis}.")
            print(kod, flush=True)

    def create_web_test(self, command):
        import pyperclip
        js_kod = """function klikniNaText(retezec) {
  const hledany = retezec.trim();
  const elementy = document.querySelectorAll('button, a, [role="button"], span, div, p, li');
  for (const el of elementy) {
    if (el.innerText && el.innerText.trim() === hledany) {
      const styl = window.getComputedStyle(el);
      if (styl.display === 'none' || styl.visibility === 'hidden') continue;
      el.click();
      console.log(`Kliknuto na: "${hledany}"`, el);
      return true;
    }
  }
  for (const el of elementy) {
    if (el.textContent && el.textContent.trim() === hledany) {
      el.click();
      return true;
    }
  }
  console.warn(`Nenalezen element s textem: "${hledany}"`);
  return false;
}
// Pouze pro vlastni testovaci stranky s povolenim
// Priklad: klikniNaText("Odeslat");
"""
        try:
            pyperclip.copy(js_kod)
            self.speak("Funkce klikniNaText je ve schrance. Pouzij jen na vlastnich strankach.")
            print(f"\nJS KOD:\n{js_kod}\n", flush=True)
        except:
            self.speak("Funkce pripravena. Zkopiruj si ji z konzole.")
            print(js_kod, flush=True)

    def process_command(self, command):
        if not command:
            return True

        # Odstran "jarvis" pokud tam je
        command = command.replace("jarvis", "").strip()
        print(f"Prikaz: '{command}'", flush=True)

        if not command:
            self.speak("Ano?")
            return True

        try:
            # Nejdriv zkontroluj naucene prikazy
            if self.check_learned(command):
                return True

            # Aktivace ma vzdy prednost pred branami
            if fuzzy_match(command, COMMANDS["klic"]):
                self.aktivovat_licenci(command)
                return True

            # Brana placenych edici
            for _k, _need in EDICE_PRIKAZU.items():
                if fuzzy_match(command, COMMANDS[_k]) and not self.smim(_need):
                    self.speak(f"Tato funkce je v edici {_need} a vyšší. Koupíš ji na našem webu.")
                    return True

            if fuzzy_match(command, COMMANDS["nauc_se"]):
                self.learn_command(command)
            elif fuzzy_match(command, COMMANDS["zapomenout"]):
                self.forget_command(command)
            elif fuzzy_match(command, COMMANDS["co_umis"]):
                self.tell_learned_facts()
            elif fuzzy_match(command, COMMANDS["povidat"]):
                self.start_chat()
            elif fuzzy_match(command, COMMANDS["pozdrav"]):
                self.speak("Ahoj! Jak vam mohu pomoci?")
            elif fuzzy_match(command, COMMANDS["cas"]):
                self.speak(f"Je {self.get_time()}")
            elif fuzzy_match(command, COMMANDS["datum"]):
                self.speak(self.get_date())
            elif fuzzy_match(command, COMMANDS["vtip"]):
                self.speak(self.tell_joke())
            elif fuzzy_match(command, COMMANDS["kdo"]):
                if "vytvoril" in command or "udelal" in command:
                    self.speak("Vytvoril me Petrak7.")
                else:
                    self.speak(f"Jsem {self.name}, vasm cesky hlasovy asistent.")
            elif fuzzy_match(command, COMMANDS["diky"]):
                self.speak("Neni zac!")
            elif fuzzy_match(command, COMMANDS["pomoc"]):
                self.speak("Muzu: cas, datum, vtip, otevrit, zavrit, prehravat hudbu, vyhledavat, spoustet hry, programovat, napsat kod, upravit kod, zapis do souboru, analyzovat kod, analyzovat VS Code, dat tipy na vylepseni, vytvorit prezentaci, godot auto.")
            elif fuzzy_match(command, COMMANDS["prezentace"]):
                self.create_presentation(command)
            elif fuzzy_match(command, COMMANDS["godot"]):
                if any(w in command for w in ["auto", "jezd", "car", "vehicle", "rid", "pohyb"]):
                    self.create_godot_car(command)
                elif any(w in command for w in ["napis", "napiš", "vytvor", "vytvoř", "kod", "kód", "script", "gdscript"]):
                    self.write_code("gdscript auto " + command)
                else:
                    self.speak("Godot! Chces jezdici auto? Rekni treba: vytvor auto v godotu.")
            elif fuzzy_match(command, COMMANDS["programovani"]):
                self.programming_help(command)
            elif fuzzy_match(command, COMMANDS["napsat"]):
                self.write_code(command)
            elif fuzzy_match(command, COMMANDS["upravit"]):
                self.edit_code(command)
            elif fuzzy_match(command, COMMANDS["najit_kod"]):
                self.find_in_code(command)
            elif fuzzy_match(command, COMMANDS["analyzovat"]):
                self.analyze_code(command)
            elif fuzzy_match(command, COMMANDS["zapis_soubor"]):
                self.write_to_file(command)
            elif fuzzy_match(command, COMMANDS["uprav_soubor"]):
                self.edit_file(command)
            elif fuzzy_match(command, COMMANDS["vscode"]):
                self.analyze_vscode()
            elif fuzzy_match(command, COMMANDS["tipy"]):
                self.suggest_code()
            elif fuzzy_match(command, COMMANDS["konec"]):
                self.speak("Na shledanou!")
                self.running = False
            elif fuzzy_match(command, COMMANDS["zavri"]):
                self.close_app(command)
            elif fuzzy_match(command, COMMANDS["tlumik"]):
                self.toggle_mute()
            elif fuzzy_match(command, COMMANDS["pripoj"]):
                self.join_call()
            elif fuzzy_match(command, COMMANDS["zaves"]):
                self.end_call()
            elif fuzzy_match(command, COMMANDS["zavolej"]):
                self.start_call(command)
            elif fuzzy_match(command, COMMANDS["vyhledej"]):
                self.search_discord(command)
            elif fuzzy_match(command, COMMANDS["stop"]):
                self.media_control("stop")
            elif fuzzy_match(command, COMMANDS["play"]):
                self.media_control("play")
            elif fuzzy_match(command, COMMANDS["stazene"]):
                downloads = os.path.join(os.path.expanduser("~"), "Downloads")
                subprocess.Popen(["explorer", downloads])
                self.speak("Oteviram stazene soubory.")
            elif fuzzy_match(command, COMMANDS["hledej"]):
                self.search_web(command)
            elif fuzzy_match(command, COMMANDS["webtest"]):
                self.create_web_test(command)
            elif fuzzy_match(command, COMMANDS["spust"]):
                self.launch_game(command)
            elif fuzzy_match(command, COMMANDS["vypni_pc"]):
                self.shutdown_pc()
            elif fuzzy_match(command, COMMANDS["restartuj"]):
                self.restart_pc()
            elif fuzzy_match(command, COMMANDS["uspi"]):
                self.sleep_pc()
            elif fuzzy_match(command, COMMANDS["uzamkni"]):
                self.lock_pc()
            elif fuzzy_match(command, COMMANDS["hlasitost"]):
                if "utichni" in command or "ztis" in command:
                    self.mute_pc()
                else:
                    self.set_volume(50)
            elif fuzzy_match(command, COMMANDS["jas"]):
                self.set_brightness(50)
            elif fuzzy_match(command, COMMANDS["wifi"]):
                self.toggle_wifi()
            elif fuzzy_match(command, COMMANDS["bluetooth"]):
                self.toggle_bluetooth()
            elif fuzzy_match(command, COMMANDS["soubory"]):
                self.open_explorer()
            elif fuzzy_match(command, COMMANDS["spravce"]):
                self.open_task_manager()
            elif fuzzy_match(command, COMMANDS["terminal"]):
                self.open_terminal()
            elif fuzzy_match(command, COMMANDS["nastaveni"]):
                self.open_settings()
            elif fuzzy_match(command, COMMANDS["oznameni"]):
                self.open_notifications()
            elif fuzzy_match(command, COMMANDS["kalkulacka"]):
                self.open_calculator()
            elif fuzzy_match(command, COMMANDS["poznamky"]):
                self.open_notepad()
            elif fuzzy_match(command, COMMANDS["snimek"]):
                self.take_screenshot()
            elif fuzzy_match(command, COMMANDS["kamera"]):
                self.see()
            elif fuzzy_match(command, COMMANDS["obrazovka"]):
                self.see_screen()
            elif fuzzy_match(command, COMMANDS["sleduj"]):
                self.start_monitoring()
                self.speak("Sleduji co delas.")
            elif fuzzy_match(command, COMMANDS["nesleduj"]):
                self.stop_monitoring()
                self.speak("Prestal jsem sledovat.")
            elif fuzzy_match(command, COMMANDS["zvyky"]):
                self.tell_habits()
            elif fuzzy_match(command, COMMANDS["google"]):
                self.open_website("google")
            elif fuzzy_match(command, COMMANDS["youtube"]):
                self.open_website("youtube")
            elif fuzzy_match(command, COMMANDS["seznam"]):
                self.open_website("seznam")
            elif fuzzy_match(command, COMMANDS["github"]):
                self.open_website("github")
            elif fuzzy_match(command, COMMANDS["brave"]):
                self.open_brave()
            elif "otevri" in command or "otevre" in command:
                for site in ["google", "youtube", "facebook", "wikipedia", "github", "seznam"]:
                    if site in command:
                        self.open_website(site)
                        return True
                self.speak("Nevim, co mam otevrit.")
            else:
                self.speak("Nerozumel jsem prikazu.")
        except Exception as e:
            print(f"Chyba prikazu: {e}", flush=True)
            self.speak("Stala se chyba.")
        return True

    def run(self):
        self.speak("J.A.R.V.I.S. systemy jsou online. Pripraven k akci.")
        self.start_monitoring()
        self.start_proactive()
        import time
        time.sleep(3)
        try:
            while self.running:
                command = self.listen()
                if self.chatting:
                    if command:
                        response = self.chat(command)
                        self.speak(response)
                        self.chat_history.append({"user": command, "jarvis": response})
                        self.save_chat_history()
                else:
                    self.process_command(command)
                time.sleep(0.5)
        except KeyboardInterrupt:
            self.speak("Systemy se vypinaji. Nashledanou.")


def text_mode():
    jarvis = JarvisCZ()
    jarvis.speak("Textovy mod. Napis prikaz nebo 'povidej si' pro konverzaci.")
    jarvis.start_monitoring()
    try:
        while jarvis.running:
            command = input("\nVy: ").lower().strip()
            if command:
                if jarvis.chatting:
                    response = jarvis.chat(command)
                    print(f"Jarvis: {response}")
                    jarvis.chat_history.append({"user": command, "jarvis": response})
                    jarvis.save_chat_history()
                else:
                    jarvis.process_command(command)
    except (KeyboardInterrupt, EOFError):
        pass


if __name__ == "__main__":
    print("=" * 50, flush=True)
    print("J.A.R.V.I.S. - Just A Rather Very Intelligent System", flush=True)
    print("=" * 50, flush=True)
    print("\n1. Hlasovy mod", flush=True)
    print("2. Textovy mod", flush=True)

    choice = input("\nVolba: ")

    if choice == "1":
        JarvisCZ().run()
    elif choice == "2":
        text_mode()
