"""
Licence J.A.R.V.I.S. - klice vazane na PC (HWID).
Kopie souboru na jine PC placene funkce neodemkne.
POZOR: vytvor-klic.py ani tento SECRET nikomu nedavej.
"""

import hashlib
import hmac
import json
import os
import uuid

SECRET = b"jarvis-cesko-2026-tajna-sul-pro-licence"
EDICE_PORADI = {"FREE": 0, "PRO": 1, "MAX": 2, "TEAM": 3, "FIRMA": 4}
ZNAKY = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

# ID Google tabulky s evidenci klicu (sloupce: klic | edice | email | stav).
# Prazdne = online kontrola vypnuta, plati jen mistni overeni.
SHEET_ID = ""


def hwid():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as k:
            v, _ = winreg.QueryValueEx(k, "MachineGuid")
            return str(v)
    except Exception:
        return hex(uuid.getnode())


def _podpis(edice, payload):
    return hmac.new(SECRET, f"{edice}:{payload}".encode(), hashlib.sha256).hexdigest()[:6].upper()


def vytvor_klic(edice="PRO"):
    import random
    edice = edice.upper().strip()
    if edice not in EDICE_PORADI or edice == "FREE":
        raise ValueError("Edice musi byt PRO, MAX, TEAM nebo FIRMA.")
    payload = "".join(random.choice(ZNAKY) for _ in range(12))
    return f"{edice}-{payload[:6]}-{payload[6:]}-{_podpis(edice, payload)}"


def over_klic(klic):
    try:
        parts = klic.upper().replace(" ", "").split("-")
        if len(parts) != 4:
            return None
        ed, p1, p2, sig = parts
        payload = p1 + p2
        if ed not in EDICE_PORADI or ed == "FREE":
            return None
        if len(payload) != 12 or not payload.isalnum():
            return None
        if hmac.compare_digest(_podpis(ed, payload), sig):
            return ed
    except Exception:
        pass
    return None


def _cesta():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "licence.dat")


MAX_PC = {"PRO": 1, "MAX": 1, "TEAM": 5, "FIRMA": 99}


def uloz_licenci(edice, klic):
    """Prida aktualni PC ke klici. Vraci (ok, zprava)."""
    try:
        with open(_cesta(), encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = {}
    if data.get("klic") != klic:
        data = {"edice": edice, "klic": klic, "hwids": []}
    hw = hashlib.sha256(hwid().encode()).hexdigest()
    if hw not in data.get("hwids", []):
        limit = MAX_PC.get(edice, 1)
        if len(data.get("hwids", [])) >= limit:
            return False, "Klic je aktivovany na jinem PC. Jeden klic plati pro jeden pocitac. Napis nam - domluvime se."
        data["hwids"].append(hw)
    with open(_cesta(), "w", encoding="utf-8") as f:
        json.dump(data, f)
    return True, "ok"


def nacti_edici():
    try:
        with open(_cesta(), encoding="utf-8") as f:
            d = json.load(f)
        if over_klic(d.get("klic", "")) != d.get("edice"):
            return "FREE"
        if hashlib.sha256(hwid().encode()).hexdigest() not in d.get("hwids", []):
            return "FREE"
        return d.get("edice", "FREE")
    except Exception:
        return "FREE"


def _sheet_rows():
    import csv
    import io
    import urllib.request
    url = f"https://docs.google.com/spreadsheets/d/{SHEET_ID}/export?format=csv"
    with urllib.request.urlopen(url, timeout=8) as r:
        return list(csv.DictReader(io.StringIO(r.read().decode("utf-8"))))


def over_online(klic):
    """Najde klic v Google Sheets. Vraci dict nebo None (vypnuto/chyba site)."""
    if not SHEET_ID:
        return None
    try:
        for row in _sheet_rows():
            if (row.get("klic") or "").strip().upper() == klic.strip().upper():
                return {
                    "nalezen": True,
                    "edice": (row.get("edice") or "").strip().upper(),
                    "aktivni": (row.get("stav") or "").strip().lower() == "aktivni",
                }
        return {"nalezen": False, "edice": "", "aktivni": False}
    except Exception as e:
        print(f"Online kontrola selhala (jedeme podle mistni licence): {e}", flush=True)
        return None


def zkontroluj_online(edice):
    """Pri startu: pokud je klic v Sheets deaktivovany, vrat FREE. Jinak puvodni edici."""
    if edice == "FREE" or not SHEET_ID:
        return edice
    try:
        with open(_cesta(), encoding="utf-8") as f:
            d = json.load(f)
        import time
        if time.time() - d.get("kontrola", 0) < 24 * 3600:
            return edice
        on = over_online(d.get("klic", ""))
        d["kontrola"] = time.time()
        with open(_cesta(), "w", encoding="utf-8") as f:
            json.dump(d, f)
        if on and on["nalezen"] and not on["aktivni"]:
            return "FREE"
        return edice
    except Exception:
        return edice
