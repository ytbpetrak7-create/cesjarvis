"""
Licence J.A.R.V.I.S. - klice vazane na PC (HWID).
Kopie souboru na jine PC placene funkce neodemkne.
POZOR: vytvor-klic.py ani tento SECRET nikomu nedavej.
"""

import hashlib
import hmac
import json
import os
import uuid

SECRET = b"jarvis-cesko-2026-tajna-sul-pro-licence"
EDICE_PORADI = {"FREE": 0, "PRO": 1, "MAX": 2, "TEAM": 3, "FIRMA": 4}
ZNAKY = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def hwid():
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as k:
            v, _ = winreg.QueryValueEx(k, "MachineGuid")
            return str(v)
    except Exception:
        return hex(uuid.getnode())


def _podpis(edice, payload):
    return hmac.new(SECRET, f"{edice}:{payload}".encode(), hashlib.sha256).hexdigest()[:6].upper()


def vytvor_klic(edice="PRO"):
    import random
    edice = edice.upper().strip()
    if edice not in EDICE_PORADI or edice == "FREE":
        raise ValueError("Edice musi byt PRO, MAX, TEAM nebo FIRMA.")
    payload = "".join(random.choice(ZNAKY) for _ in range(12))
    return f"{edice}-{payload[:6]}-{payload[6:]}-{_podpis(edice, payload)}"


def over_klic(klic):
    try:
        parts = klic.upper().replace(" ", "").split("-")
        if len(parts) != 4:
            return None
        ed, p1, p2, sig = parts
        payload = p1 + p2
        if ed not in EDICE_PORADI or ed == "FREE":
            return None
        if len(payload) != 12 or not payload.isalnum():
            return None
        if hmac.compare_digest(_podpis(ed, payload), sig):
            return ed
    except Exception:
        pass
    return None


def _cesta():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "licence.dat")


def uloz_licenci(edice, klic):
    data = {
        "edice": edice,
        "klic": klic,
        "hwid": hashlib.sha256(hwid().encode()).hexdigest(),
    }
    with open(_cesta(), "w", encoding="utf-8") as f:
        json.dump(data, f)


def nacti_edici():
    try:
        with open(_cesta(), encoding="utf-8") as f:
            d = json.load(f)
        if over_klic(d.get("klic", "")) != d.get("edice"):
            return "FREE"
        if d.get("hwid") != hashlib.sha256(hwid().encode()).hexdigest():
            return "FREE"
        return d.get("edice", "FREE")
    except Exception:
        return "FREE"
