Add-Type -AssemblyName PresentationCore
$path = $args[0]
$p = New-Object System.Windows.Media.MediaPlayer
$p.Open([uri]::new($path))
$p.Play()
Start-Sleep -Milliseconds 500
while($p.Position -lt $p.NaturalDuration.TimeSpan) {
    Start-Sleep -Milliseconds 200
}
$p.Close()
