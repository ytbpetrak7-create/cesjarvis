@echo off
echo Pridavam do autostartu...

set SCRIPT_DIR=%~dp0
set AUTOSTART=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup

echo Set oWS = WScript.CreateObject("WScript.Shell") > "%AUTOSTART%\Jarvis-Listener.vbs"
echo Set oLink = oWS.CreateShortcut("%AUTOSTART%\Jarvis-Listener.lnk") >> "%AUTOSTART%\Jarvis-Listener.vbs"
echo oLink.TargetPath = "%SCRIPT_DIR%spust-listener.bat" >> "%AUTOSTART%\Jarvis-Listener.vbs"
echo oLink.WorkingDirectory = "%SCRIPT_DIR%" >> "%AUTOSTART%\Jarvis-Listener.vbs"
echo oLink.WindowStyle = 7 >> "%AUTOSTART%\Jarvis-Listener.vbs"
echo oLink.Save >> "%AUTOSTART%\Jarvis-Listener.vbs"

del "%AUTOSTART%\Jarvis-Listener.vbs"

echo Hotovo! Jarvis se bude spoustet pri startu Windows.
echo Rekni 'Jarvis' a on se zapne!
pause
