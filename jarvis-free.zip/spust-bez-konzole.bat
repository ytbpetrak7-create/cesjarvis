@echo off
start /min pythonw start.pyw
