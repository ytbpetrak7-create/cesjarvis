@echo off
start /min pythonw jarvis-listener.pyw
