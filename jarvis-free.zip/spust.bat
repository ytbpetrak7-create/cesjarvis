@echo off
title J.A.R.V.I.S.
python jarvis.py
pause
