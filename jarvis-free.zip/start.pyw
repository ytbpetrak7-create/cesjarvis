import subprocess
import sys
import os

# Spusti jarvis.py bez konzole
script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "jarvis.py")
subprocess.Popen([sys.executable, script], creationflags=subprocess.CREATE_NO_WINDOW | subprocess.SW_HIDE)
