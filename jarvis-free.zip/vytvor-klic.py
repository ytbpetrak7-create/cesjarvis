"""Generator licencnich klicu - JEN PRO ADMINA. Nikomu nedavat."""
import sys

from licence import vytvor_klic

if __name__ == "__main__":
    edice = (sys.argv[1] if len(sys.argv) > 1 else "PRO").upper()
    email = sys.argv[2] if len(sys.argv) > 2 else ""
    try:
        klic = vytvor_klic(edice)
        print(klic)
        print(f"Radek do Google Sheets (klic | edice | email | stav):")
        print(f"{klic}\t{edice}\t{email}\taktivni")
    except ValueError as e:
        print(f"Chyba: {e}")
        print("Pouziti: python vytvor-klic.py [PRO|MAX|TEAM|FIRMA] [email_kupce]")
