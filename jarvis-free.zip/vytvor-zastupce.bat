@echo off
echo Vytvarim zastupce na ploche...
set SCRIPT_DIR=%~dp0
set DESKTOP=%USERPROFILE%\Desktop

echo Set oWS = WScript.CreateObject("WScript.Shell") > "%DESKTOP%\Jarvis.vbs"
echo Set oLink = oWS.CreateShortcut("%DESKTOP%\Jarvis.lnk") >> "%DESKTOP%\Jarvis.vbs"
echo oLink.TargetPath = "%SCRIPT_DIR%spust-bez-konzole.bat" >> "%DESKTOP%\Jarvis.vbs"
echo oLink.WorkingDirectory = "%SCRIPT_DIR%" >> "%DESKTOP%\Jarvis.vbs"
echo oLink.Description = "J.A.R.V.I.S. - Cesky hlasovy asistent" >> "%DESKTOP%\Jarvis.vbs"
echo oLink.Save >> "%DESKTOP%\Jarvis.vbs"

del "%DESKTOP%\Jarvis.vbs"
echo Hotovo! Zastupce "Jarvis" je na ploche.
pause
