import pyautogui
import time

print("Presun myš na tlačítko volání v Discordu.")
print("Když budeš na správném místě, zmáčkni Enter.")
print()

input("Když jsi připraven, zmáčkni Enter...")

x, y = pyautogui.position()
print(f"Souradnice: {x}, {y}")
print(f"Pouzij: call_x = {x}, call_y = {y}")
